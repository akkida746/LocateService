package com.microsretail.locate;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringReader;
import java.util.Enumeration;
import java.util.Map;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletInputStream;
import javax.servlet.ServletOutputStream;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletResponseWrapper;
import javax.xml.transform.TransformerException;

public class WsRequestXsltFilter implements Filter {

	private FilterConfig filterConfig;

	@Override
	public void destroy() {
		this.filterConfig = null;
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {

		InputStream inStream = null;
		BufferedReader br = null;

		PrintWriter out = response.getWriter();

		try {

			/*HttpServletResponseWrapper wrapper = new HttpServletResponseWrapper(
					(HttpServletResponse) response);*/

			MultiReadHttpServletRequest requestWrapper = new MultiReadHttpServletRequest(
					(HttpServletRequest) request);

			chain.doFilter(requestWrapper, response);

			String filePath = getResponseFilePath(requestWrapper);

			if (filePath.length() > 1) {

				StringBuilder sb = new StringBuilder();

				if (filePath.length() > 2) {
					inStream = request.getServletContext().getResourceAsStream(
							filePath);

					String line;
					br = new BufferedReader(new InputStreamReader(inStream));
					while ((line = br.readLine()) != null) {
						sb.append(line);
					}
				}

				response.setContentLength(sb.length());
				out.write(sb.toString());

			} else {

				String path = ((HttpServletRequest) request).getContextPath();

				((HttpServletResponse) response).setContentType("text/xml");
				((HttpServletResponse) response).sendRedirect(path
						+ "/wsdl/LocateServices.wsdl");
			}

		} finally {
			if (inStream != null)
				inStream.close();
			if (br != null)
				br.close();
			if (out != null)
				out.close();
		}

	}

	@Override
	public void init(FilterConfig filterConfig) throws ServletException {
		this.filterConfig = filterConfig;
	}

	private String getResponseFilePath(
			MultiReadHttpServletRequest requestWrapper) {

		String filePath = "";
		StringBuilder sb = new StringBuilder();
		BufferedReader br = null;

		String line = "";
		try {
			br = new BufferedReader(new InputStreamReader(
					requestWrapper.getInputStream()));

			while ((line = br.readLine()) != null) {
				sb.append(line);
			}

			String data = sb.toString();
			System.out.println(data);

			if (data.contains("OrderSearch"))
				filePath = "/WEB-INF/XmlFiles/OrderSearchResponse.xml";
			else if (data.contains("OrderUpdate"))
				filePath = "/WEB-INF/XmlFiles/OrderUpdateResponse.xml";
			else if (data.contains("Fulfillments"))
				filePath = "/WEB-INF/XmlFiles/FulFillmentResponse.xml";

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			if (br != null)
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}

		return filePath;
	}

	class MultiReadHttpServletRequest extends HttpServletRequestWrapper {
		private String _body;

		public MultiReadHttpServletRequest(HttpServletRequest request)
				throws IOException {
			super(request);
			_body = "";
			BufferedReader bufferedReader = request.getReader();
			String line;
			while ((line = bufferedReader.readLine()) != null) {
				_body += line;
			}
		}

		@Override
		public ServletInputStream getInputStream() throws IOException {
			final ByteArrayInputStream byteArrayInputStream = new ByteArrayInputStream(
					_body.getBytes());
			return new ServletInputStream() {
				public int read() throws IOException {
					return byteArrayInputStream.read();
				}
			};
		}

		@Override
		public BufferedReader getReader() throws IOException {
			return new BufferedReader(new InputStreamReader(
					this.getInputStream()));
		}
	}
}
