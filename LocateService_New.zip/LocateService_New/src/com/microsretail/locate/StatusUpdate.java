
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusUpdate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusUpdate"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="status_update_request_message" type="{http://microsretail.com/Locate}StatusUpdateRequestMessageTypeBean" minOccurs="0" form="qualified"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusUpdate", propOrder = {
    "statusUpdateRequestMessage"
})
public class StatusUpdate {

    @XmlElement(name = "status_update_request_message", namespace = "http://microsretail.com/Locate")
    protected StatusUpdateRequestMessageTypeBean statusUpdateRequestMessage;

    /**
     * Gets the value of the statusUpdateRequestMessage property.
     * 
     * @return
     *     possible object is
     *     {@link StatusUpdateRequestMessageTypeBean }
     *     
     */
    public StatusUpdateRequestMessageTypeBean getStatusUpdateRequestMessage() {
        return statusUpdateRequestMessage;
    }

    /**
     * Sets the value of the statusUpdateRequestMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusUpdateRequestMessageTypeBean }
     *     
     */
    public void setStatusUpdateRequestMessage(StatusUpdateRequestMessageTypeBean value) {
        this.statusUpdateRequestMessage = value;
    }

}
