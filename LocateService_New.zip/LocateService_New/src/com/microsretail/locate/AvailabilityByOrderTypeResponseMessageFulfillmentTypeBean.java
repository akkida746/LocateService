
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeResponseMessageItemsTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="type" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="response_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="response_description" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean", propOrder = {
    "items"
})
public class AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean {

    protected AvailabilityByOrderTypeResponseMessageItemsTypeBean items;
    @XmlAttribute(name = "type")
    protected String type;
    @XmlAttribute(name = "response_cd")
    protected String responseCd;
    @XmlAttribute(name = "response_description")
    protected String responseDescription;

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link AvailabilityByOrderTypeResponseMessageItemsTypeBean }
     *     
     */
    public AvailabilityByOrderTypeResponseMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailabilityByOrderTypeResponseMessageItemsTypeBean }
     *     
     */
    public void setItems(AvailabilityByOrderTypeResponseMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the type property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getType() {
        return type;
    }

    /**
     * Sets the value of the type property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setType(String value) {
        this.type = value;
    }

    /**
     * Gets the value of the responseCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseCd() {
        return responseCd;
    }

    /**
     * Sets the value of the responseCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseCd(String value) {
        this.responseCd = value;
    }

    /**
     * Gets the value of the responseDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseDescription() {
        return responseDescription;
    }

    /**
     * Sets the value of the responseDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseDescription(String value) {
        this.responseDescription = value;
    }

}
