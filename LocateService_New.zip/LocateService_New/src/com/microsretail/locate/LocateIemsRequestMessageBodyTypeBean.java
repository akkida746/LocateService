
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocateIemsRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocateIemsRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}LocateItemsRequestMessageItemsTypeBean"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}LocateItemsRequestMessageStoreLocationTypeBean"/&gt;
 *         &lt;element name="address" type="{http://microsretail.com/Locate}LocateItemsRequestMessageAddressTypeBean"/&gt;
 *         &lt;element name="range" type="{http://microsretail.com/Locate}LocateItemsRequestMessageRangeTypeBean"/&gt;
 *         &lt;element name="requested_location" type="{http://microsretail.com/Locate}LocateItemsRequestMessageRequestedLocationTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocateIemsRequestMessageBodyTypeBean", propOrder = {
    "items",
    "storeLocation",
    "address",
    "range",
    "requestedLocation"
})
public class LocateIemsRequestMessageBodyTypeBean {

    @XmlElement(required = true)
    protected LocateItemsRequestMessageItemsTypeBean items;
    @XmlElement(name = "store_location", required = true)
    protected LocateItemsRequestMessageStoreLocationTypeBean storeLocation;
    @XmlElement(required = true)
    protected LocateItemsRequestMessageAddressTypeBean address;
    @XmlElement(required = true)
    protected LocateItemsRequestMessageRangeTypeBean range;
    @XmlElement(name = "requested_location", required = true)
    protected LocateItemsRequestMessageRequestedLocationTypeBean requestedLocation;

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageItemsTypeBean }
     *     
     */
    public LocateItemsRequestMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageItemsTypeBean }
     *     
     */
    public void setItems(LocateItemsRequestMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageStoreLocationTypeBean }
     *     
     */
    public LocateItemsRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(LocateItemsRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageAddressTypeBean }
     *     
     */
    public LocateItemsRequestMessageAddressTypeBean getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageAddressTypeBean }
     *     
     */
    public void setAddress(LocateItemsRequestMessageAddressTypeBean value) {
        this.address = value;
    }

    /**
     * Gets the value of the range property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageRangeTypeBean }
     *     
     */
    public LocateItemsRequestMessageRangeTypeBean getRange() {
        return range;
    }

    /**
     * Sets the value of the range property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageRangeTypeBean }
     *     
     */
    public void setRange(LocateItemsRequestMessageRangeTypeBean value) {
        this.range = value;
    }

    /**
     * Gets the value of the requestedLocation property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageRequestedLocationTypeBean }
     *     
     */
    public LocateItemsRequestMessageRequestedLocationTypeBean getRequestedLocation() {
        return requestedLocation;
    }

    /**
     * Sets the value of the requestedLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageRequestedLocationTypeBean }
     *     
     */
    public void setRequestedLocation(LocateItemsRequestMessageRequestedLocationTypeBean value) {
        this.requestedLocation = value;
    }

}
