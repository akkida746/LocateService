
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FulfillmentResponseMessageOrderTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FulfillmentResponseMessageOrderTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="transaction_date" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="employee_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="transaction_subtotal" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="transaction_tax" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="transaction_total" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="special_instructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="transaction_channel" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="ship_via" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="ship_via_description" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="gift" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="source_code" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="freight_amount" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="balance_due" type="{http://www.w3.org/2001/XMLSchema}double" minOccurs="0"/&gt;
 *         &lt;element name="currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="under_review" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="order_additional_freight_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="order_additional_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="ship_complete" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="freight_tax" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="order_message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="gift_message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="sold_to_customer" type="{http://microsretail.com/Locate}SoldToCustomerTypeBean" minOccurs="0"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}FulfillmentResponseMessageStoreLocationTypeBean"/&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}FulfillmentResponseMessageItemsTypeBean" minOccurs="0"/&gt;
 *         &lt;element name="transaction_tenders" type="{http://microsretail.com/Locate}TransactionTendersTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="transaction_no" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="transaction_type_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="order_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="transaction_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FulfillmentResponseMessageOrderTypeBean", propOrder = {
    "refTransactionNo",
    "transactionDate",
    "employeeId",
    "transactionSubtotal",
    "transactionTax",
    "transactionTotal",
    "specialInstructions",
    "transactionChannel",
    "shipVia",
    "shipViaDescription",
    "gift",
    "sourceCode",
    "freightAmount",
    "balanceDue",
    "currency",
    "underReview",
    "orderAdditionalFreightCharges",
    "orderAdditionalCharges",
    "shipComplete",
    "freightTax",
    "orderMessage",
    "giftMessage",
    "soldToCustomer",
    "storeLocation",
    "items",
    "transactionTenders"
})
public class FulfillmentResponseMessageOrderTypeBean {

    @XmlElement(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlElement(name = "transaction_date", required = true)
    protected String transactionDate;
    @XmlElement(name = "employee_id", required = true)
    protected String employeeId;
    @XmlElement(name = "transaction_subtotal")
    protected double transactionSubtotal;
    @XmlElement(name = "transaction_tax")
    protected double transactionTax;
    @XmlElement(name = "transaction_total")
    protected double transactionTotal;
    @XmlElement(name = "special_instructions")
    protected String specialInstructions;
    @XmlElement(name = "transaction_channel", required = true)
    protected String transactionChannel;
    @XmlElement(name = "ship_via")
    protected String shipVia;
    @XmlElement(name = "ship_via_description")
    protected String shipViaDescription;
    protected String gift;
    @XmlElement(name = "source_code")
    protected String sourceCode;
    @XmlElement(name = "freight_amount")
    protected Double freightAmount;
    @XmlElement(name = "balance_due")
    protected Double balanceDue;
    protected String currency;
    @XmlElement(name = "under_review")
    protected String underReview;
    @XmlElement(name = "order_additional_freight_charges")
    protected BigDecimal orderAdditionalFreightCharges;
    @XmlElement(name = "order_additional_charges")
    protected BigDecimal orderAdditionalCharges;
    @XmlElement(name = "ship_complete")
    protected String shipComplete;
    @XmlElement(name = "freight_tax")
    protected BigDecimal freightTax;
    @XmlElement(name = "order_message")
    protected String orderMessage;
    @XmlElement(name = "gift_message")
    protected String giftMessage;
    @XmlElement(name = "sold_to_customer")
    protected SoldToCustomerTypeBean soldToCustomer;
    @XmlElement(name = "store_location", required = true)
    protected FulfillmentResponseMessageStoreLocationTypeBean storeLocation;
    protected FulfillmentResponseMessageItemsTypeBean items;
    @XmlElement(name = "transaction_tenders")
    protected TransactionTendersTypeBean transactionTenders;
    @XmlAttribute(name = "transaction_no", required = true)
    protected String transactionNo;
    @XmlAttribute(name = "transaction_type_id", required = true)
    protected String transactionTypeId;
    @XmlAttribute(name = "request_id", required = true)
    protected int requestId;
    @XmlAttribute(name = "order_id", required = true)
    protected String orderId;
    @XmlAttribute(name = "transaction_status", required = true)
    protected String transactionStatus;

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the transactionDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionDate() {
        return transactionDate;
    }

    /**
     * Sets the value of the transactionDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionDate(String value) {
        this.transactionDate = value;
    }

    /**
     * Gets the value of the employeeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the value of the employeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeId(String value) {
        this.employeeId = value;
    }

    /**
     * Gets the value of the transactionSubtotal property.
     * 
     */
    public double getTransactionSubtotal() {
        return transactionSubtotal;
    }

    /**
     * Sets the value of the transactionSubtotal property.
     * 
     */
    public void setTransactionSubtotal(double value) {
        this.transactionSubtotal = value;
    }

    /**
     * Gets the value of the transactionTax property.
     * 
     */
    public double getTransactionTax() {
        return transactionTax;
    }

    /**
     * Sets the value of the transactionTax property.
     * 
     */
    public void setTransactionTax(double value) {
        this.transactionTax = value;
    }

    /**
     * Gets the value of the transactionTotal property.
     * 
     */
    public double getTransactionTotal() {
        return transactionTotal;
    }

    /**
     * Sets the value of the transactionTotal property.
     * 
     */
    public void setTransactionTotal(double value) {
        this.transactionTotal = value;
    }

    /**
     * Gets the value of the specialInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialInstructions() {
        return specialInstructions;
    }

    /**
     * Sets the value of the specialInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialInstructions(String value) {
        this.specialInstructions = value;
    }

    /**
     * Gets the value of the transactionChannel property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionChannel() {
        return transactionChannel;
    }

    /**
     * Sets the value of the transactionChannel property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionChannel(String value) {
        this.transactionChannel = value;
    }

    /**
     * Gets the value of the shipVia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipVia() {
        return shipVia;
    }

    /**
     * Sets the value of the shipVia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipVia(String value) {
        this.shipVia = value;
    }

    /**
     * Gets the value of the shipViaDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipViaDescription() {
        return shipViaDescription;
    }

    /**
     * Sets the value of the shipViaDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipViaDescription(String value) {
        this.shipViaDescription = value;
    }

    /**
     * Gets the value of the gift property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGift() {
        return gift;
    }

    /**
     * Sets the value of the gift property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGift(String value) {
        this.gift = value;
    }

    /**
     * Gets the value of the sourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Sets the value of the sourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Gets the value of the freightAmount property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFreightAmount() {
        return freightAmount;
    }

    /**
     * Sets the value of the freightAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFreightAmount(Double value) {
        this.freightAmount = value;
    }

    /**
     * Gets the value of the balanceDue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getBalanceDue() {
        return balanceDue;
    }

    /**
     * Sets the value of the balanceDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setBalanceDue(Double value) {
        this.balanceDue = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Gets the value of the underReview property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderReview() {
        return underReview;
    }

    /**
     * Sets the value of the underReview property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderReview(String value) {
        this.underReview = value;
    }

    /**
     * Gets the value of the orderAdditionalFreightCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalFreightCharges() {
        return orderAdditionalFreightCharges;
    }

    /**
     * Sets the value of the orderAdditionalFreightCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalFreightCharges(BigDecimal value) {
        this.orderAdditionalFreightCharges = value;
    }

    /**
     * Gets the value of the orderAdditionalCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalCharges() {
        return orderAdditionalCharges;
    }

    /**
     * Sets the value of the orderAdditionalCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalCharges(BigDecimal value) {
        this.orderAdditionalCharges = value;
    }

    /**
     * Gets the value of the shipComplete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipComplete() {
        return shipComplete;
    }

    /**
     * Sets the value of the shipComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipComplete(String value) {
        this.shipComplete = value;
    }

    /**
     * Gets the value of the freightTax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFreightTax() {
        return freightTax;
    }

    /**
     * Sets the value of the freightTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFreightTax(BigDecimal value) {
        this.freightTax = value;
    }

    /**
     * Gets the value of the orderMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderMessage() {
        return orderMessage;
    }

    /**
     * Sets the value of the orderMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderMessage(String value) {
        this.orderMessage = value;
    }

    /**
     * Gets the value of the giftMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftMessage() {
        return giftMessage;
    }

    /**
     * Sets the value of the giftMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftMessage(String value) {
        this.giftMessage = value;
    }

    /**
     * Gets the value of the soldToCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link SoldToCustomerTypeBean }
     *     
     */
    public SoldToCustomerTypeBean getSoldToCustomer() {
        return soldToCustomer;
    }

    /**
     * Sets the value of the soldToCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link SoldToCustomerTypeBean }
     *     
     */
    public void setSoldToCustomer(SoldToCustomerTypeBean value) {
        this.soldToCustomer = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentResponseMessageStoreLocationTypeBean }
     *     
     */
    public FulfillmentResponseMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentResponseMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(FulfillmentResponseMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentResponseMessageItemsTypeBean }
     *     
     */
    public FulfillmentResponseMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentResponseMessageItemsTypeBean }
     *     
     */
    public void setItems(FulfillmentResponseMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the transactionTenders property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionTendersTypeBean }
     *     
     */
    public TransactionTendersTypeBean getTransactionTenders() {
        return transactionTenders;
    }

    /**
     * Sets the value of the transactionTenders property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionTendersTypeBean }
     *     
     */
    public void setTransactionTenders(TransactionTendersTypeBean value) {
        this.transactionTenders = value;
    }

    /**
     * Gets the value of the transactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionNo() {
        return transactionNo;
    }

    /**
     * Sets the value of the transactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionNo(String value) {
        this.transactionNo = value;
    }

    /**
     * Gets the value of the transactionTypeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionTypeId() {
        return transactionTypeId;
    }

    /**
     * Sets the value of the transactionTypeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionTypeId(String value) {
        this.transactionTypeId = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     */
    public int getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     */
    public void setRequestId(int value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the transactionStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransactionStatus() {
        return transactionStatus;
    }

    /**
     * Sets the value of the transactionStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransactionStatus(String value) {
        this.transactionStatus = value;
    }

}
