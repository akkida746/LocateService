
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderUpdateRequestMessageOrderTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderUpdateRequestMessageOrderTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="employee_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}OrderUpdateRequestMessageStoreLocationTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="request_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="under_review" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderUpdateRequestMessageOrderTypeBean", propOrder = {
    "employeeId",
    "storeLocation"
})
public class OrderUpdateRequestMessageOrderTypeBean {

    @XmlElement(name = "employee_id", required = true)
    protected String employeeId;
    @XmlElement(name = "store_location")
    protected OrderUpdateRequestMessageStoreLocationTypeBean storeLocation;
    @XmlAttribute(name = "request_id", required = true)
    protected String requestId;
    @XmlAttribute(name = "order_id", required = true)
    protected String orderId;
    @XmlAttribute(name = "under_review", required = true)
    protected String underReview;

    /**
     * Gets the value of the employeeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the value of the employeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeId(String value) {
        this.employeeId = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link OrderUpdateRequestMessageStoreLocationTypeBean }
     *     
     */
    public OrderUpdateRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderUpdateRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(OrderUpdateRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the underReview property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderReview() {
        return underReview;
    }

    /**
     * Sets the value of the underReview property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderReview(String value) {
        this.underReview = value;
    }

}
