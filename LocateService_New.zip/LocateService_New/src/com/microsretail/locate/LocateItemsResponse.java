
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocateItemsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocateItemsResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="location_response_message" type="{http://microsretail.com/Locate}LocateItemsResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocateItemsResponse", propOrder = {
    "locationResponseMessage"
})
public class LocateItemsResponse {

    @XmlElement(name = "location_response_message")
    protected LocateItemsResponseMessageTypeBean locationResponseMessage;

    /**
     * Gets the value of the locationResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsResponseMessageTypeBean }
     *     
     */
    public LocateItemsResponseMessageTypeBean getLocationResponseMessage() {
        return locationResponseMessage;
    }

    /**
     * Sets the value of the locationResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsResponseMessageTypeBean }
     *     
     */
    public void setLocationResponseMessage(LocateItemsResponseMessageTypeBean value) {
        this.locationResponseMessage = value;
    }

}
