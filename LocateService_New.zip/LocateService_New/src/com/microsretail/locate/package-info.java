@javax.xml.bind.annotation.XmlSchema(namespace = "http://microsretail.com/Locate")
package com.microsretail.locate;
