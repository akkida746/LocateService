
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SubmitOrderResponseMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubmitOrderResponseMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="response" type="{http://microsretail.com/Locate}SubmitOrderResponseMessageResponseTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubmitOrderResponseMessageBodyTypeBean", propOrder = {
    "response"
})
public class SubmitOrderResponseMessageBodyTypeBean {

    @XmlElement(required = true)
    protected SubmitOrderResponseMessageResponseTypeBean response;

    /**
     * Gets the value of the response property.
     * 
     * @return
     *     possible object is
     *     {@link SubmitOrderResponseMessageResponseTypeBean }
     *     
     */
    public SubmitOrderResponseMessageResponseTypeBean getResponse() {
        return response;
    }

    /**
     * Sets the value of the response property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubmitOrderResponseMessageResponseTypeBean }
     *     
     */
    public void setResponse(SubmitOrderResponseMessageResponseTypeBean value) {
        this.response = value;
    }

}
