
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderUpdate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderUpdate"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order_update_request_message" type="{http://microsretail.com/Locate}OrderUpdateRequestMessageTypeBean" minOccurs="0" form="qualified"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderUpdate", propOrder = {
    "orderUpdateRequestMessage"
})
public class OrderUpdate {

    @XmlElement(name = "order_update_request_message", namespace = "http://microsretail.com/Locate")
    protected OrderUpdateRequestMessageTypeBean orderUpdateRequestMessage;

    /**
     * Gets the value of the orderUpdateRequestMessage property.
     * 
     * @return
     *     possible object is
     *     {@link OrderUpdateRequestMessageTypeBean }
     *     
     */
    public OrderUpdateRequestMessageTypeBean getOrderUpdateRequestMessage() {
        return orderUpdateRequestMessage;
    }

    /**
     * Sets the value of the orderUpdateRequestMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderUpdateRequestMessageTypeBean }
     *     
     */
    public void setOrderUpdateRequestMessage(OrderUpdateRequestMessageTypeBean value) {
        this.orderUpdateRequestMessage = value;
    }

}
