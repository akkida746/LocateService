
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusUpdateResponseMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusUpdateResponseMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="response" type="{http://microsretail.com/Locate}StatusUpdateResponseMessageResponseTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusUpdateResponseMessageBodyTypeBean", propOrder = {
    "response"
})
public class StatusUpdateResponseMessageBodyTypeBean {

    @XmlElement(required = true)
    protected StatusUpdateResponseMessageResponseTypeBean response;

    /**
     * Gets the value of the response property.
     * 
     * @return
     *     possible object is
     *     {@link StatusUpdateResponseMessageResponseTypeBean }
     *     
     */
    public StatusUpdateResponseMessageResponseTypeBean getResponse() {
        return response;
    }

    /**
     * Sets the value of the response property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusUpdateResponseMessageResponseTypeBean }
     *     
     */
    public void setResponse(StatusUpdateResponseMessageResponseTypeBean value) {
        this.response = value;
    }

}
