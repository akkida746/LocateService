
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusInquiryRequestMessageStoreLocationTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusInquiryRequestMessageStoreLocationTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="location_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="system_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusInquiryRequestMessageStoreLocationTypeBean")
public class StatusInquiryRequestMessageStoreLocationTypeBean {

    @XmlAttribute(name = "location_cd")
    protected String locationCd;
    @XmlAttribute(name = "system_cd")
    protected String systemCd;

    /**
     * Gets the value of the locationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCd() {
        return locationCd;
    }

    /**
     * Sets the value of the locationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCd(String value) {
        this.locationCd = value;
    }

    /**
     * Gets the value of the systemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemCd() {
        return systemCd;
    }

    /**
     * Sets the value of the systemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemCd(String value) {
        this.systemCd = value;
    }

}
