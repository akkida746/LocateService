
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusListRequestResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusListRequestResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="status_list_request_message" type="{http://microsretail.com/Locate}StatusListInquiryResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusListRequestResponse", propOrder = {
    "statusListRequestMessage"
})
public class StatusListRequestResponse {

    @XmlElement(name = "status_list_request_message")
    protected StatusListInquiryResponseMessageTypeBean statusListRequestMessage;

    /**
     * Gets the value of the statusListRequestMessage property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryResponseMessageTypeBean }
     *     
     */
    public StatusListInquiryResponseMessageTypeBean getStatusListRequestMessage() {
        return statusListRequestMessage;
    }

    /**
     * Sets the value of the statusListRequestMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryResponseMessageTypeBean }
     *     
     */
    public void setStatusListRequestMessage(StatusListInquiryResponseMessageTypeBean value) {
        this.statusListRequestMessage = value;
    }

}
