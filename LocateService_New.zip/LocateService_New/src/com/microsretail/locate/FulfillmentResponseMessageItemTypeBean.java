
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FulfillmentResponseMessageItemTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FulfillmentResponseMessageItemTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="location_cd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="system_cd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="item_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="qty" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="unit_price" type="{http://www.w3.org/2001/XMLSchema}double"/&gt;
 *         &lt;element name="ship_to" type="{http://microsretail.com/Locate}customerTypeBean"/&gt;
 *         &lt;element name="taxes" type="{http://microsretail.com/Locate}TaxesTypeBean"/&gt;
 *         &lt;element name="special_instructions" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="item_upc_cd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="item_ean_cd" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="order_line_extended_freight" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="order_line_customization_charge" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="order_line_gift_wrap" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="order_line_ship_alone" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="order_line_ship_weight" type="{http://www.w3.org/2001/XMLSchema}decimal" minOccurs="0"/&gt;
 *         &lt;element name="order_line_message" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="customizations" type="{http://microsretail.com/Locate}DSSalesOrderCustomizationsTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="requesting_system_line_no" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="line_item_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="line_item_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FulfillmentResponseMessageItemTypeBean", propOrder = {
    "locationCd",
    "systemCd",
    "itemId",
    "qty",
    "unitPrice",
    "shipTo",
    "taxes",
    "specialInstructions",
    "itemUpcCd",
    "itemEanCd",
    "orderLineExtendedFreight",
    "orderLineCustomizationCharge",
    "orderLineGiftWrap",
    "orderLineShipAlone",
    "orderLineShipWeight",
    "orderLineMessage",
    "customizations"
})
public class FulfillmentResponseMessageItemTypeBean {

    @XmlElement(name = "location_cd")
    protected String locationCd;
    @XmlElement(name = "system_cd")
    protected String systemCd;
    @XmlElement(name = "item_id", required = true)
    protected String itemId;
    protected int qty;
    @XmlElement(name = "unit_price")
    protected double unitPrice;
    @XmlElement(name = "ship_to", required = true)
    protected CustomerTypeBean shipTo;
    @XmlElement(required = true)
    protected TaxesTypeBean taxes;
    @XmlElement(name = "special_instructions")
    protected String specialInstructions;
    @XmlElement(name = "item_upc_cd")
    protected String itemUpcCd;
    @XmlElement(name = "item_ean_cd")
    protected String itemEanCd;
    @XmlElement(name = "order_line_extended_freight")
    protected BigDecimal orderLineExtendedFreight;
    @XmlElement(name = "order_line_customization_charge")
    protected BigDecimal orderLineCustomizationCharge;
    @XmlElement(name = "order_line_gift_wrap")
    protected String orderLineGiftWrap;
    @XmlElement(name = "order_line_ship_alone")
    protected String orderLineShipAlone;
    @XmlElement(name = "order_line_ship_weight")
    protected BigDecimal orderLineShipWeight;
    @XmlElement(name = "order_line_message")
    protected String orderLineMessage;
    protected DSSalesOrderCustomizationsTypeBean customizations;
    @XmlAttribute(name = "requesting_system_line_no")
    protected String requestingSystemLineNo;
    @XmlAttribute(name = "line_item_status", required = true)
    protected String lineItemStatus;
    @XmlAttribute(name = "line_item_no", required = true)
    protected int lineItemNo;

    /**
     * Gets the value of the locationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCd() {
        return locationCd;
    }

    /**
     * Sets the value of the locationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCd(String value) {
        this.locationCd = value;
    }

    /**
     * Gets the value of the systemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemCd() {
        return systemCd;
    }

    /**
     * Sets the value of the systemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemCd(String value) {
        this.systemCd = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the qty property.
     * 
     */
    public int getQty() {
        return qty;
    }

    /**
     * Sets the value of the qty property.
     * 
     */
    public void setQty(int value) {
        this.qty = value;
    }

    /**
     * Gets the value of the unitPrice property.
     * 
     */
    public double getUnitPrice() {
        return unitPrice;
    }

    /**
     * Sets the value of the unitPrice property.
     * 
     */
    public void setUnitPrice(double value) {
        this.unitPrice = value;
    }

    /**
     * Gets the value of the shipTo property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerTypeBean }
     *     
     */
    public CustomerTypeBean getShipTo() {
        return shipTo;
    }

    /**
     * Sets the value of the shipTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerTypeBean }
     *     
     */
    public void setShipTo(CustomerTypeBean value) {
        this.shipTo = value;
    }

    /**
     * Gets the value of the taxes property.
     * 
     * @return
     *     possible object is
     *     {@link TaxesTypeBean }
     *     
     */
    public TaxesTypeBean getTaxes() {
        return taxes;
    }

    /**
     * Sets the value of the taxes property.
     * 
     * @param value
     *     allowed object is
     *     {@link TaxesTypeBean }
     *     
     */
    public void setTaxes(TaxesTypeBean value) {
        this.taxes = value;
    }

    /**
     * Gets the value of the specialInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialInstructions() {
        return specialInstructions;
    }

    /**
     * Sets the value of the specialInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialInstructions(String value) {
        this.specialInstructions = value;
    }

    /**
     * Gets the value of the itemUpcCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemUpcCd() {
        return itemUpcCd;
    }

    /**
     * Sets the value of the itemUpcCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemUpcCd(String value) {
        this.itemUpcCd = value;
    }

    /**
     * Gets the value of the itemEanCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemEanCd() {
        return itemEanCd;
    }

    /**
     * Sets the value of the itemEanCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemEanCd(String value) {
        this.itemEanCd = value;
    }

    /**
     * Gets the value of the orderLineExtendedFreight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineExtendedFreight() {
        return orderLineExtendedFreight;
    }

    /**
     * Sets the value of the orderLineExtendedFreight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineExtendedFreight(BigDecimal value) {
        this.orderLineExtendedFreight = value;
    }

    /**
     * Gets the value of the orderLineCustomizationCharge property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineCustomizationCharge() {
        return orderLineCustomizationCharge;
    }

    /**
     * Sets the value of the orderLineCustomizationCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineCustomizationCharge(BigDecimal value) {
        this.orderLineCustomizationCharge = value;
    }

    /**
     * Gets the value of the orderLineGiftWrap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineGiftWrap() {
        return orderLineGiftWrap;
    }

    /**
     * Sets the value of the orderLineGiftWrap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineGiftWrap(String value) {
        this.orderLineGiftWrap = value;
    }

    /**
     * Gets the value of the orderLineShipAlone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineShipAlone() {
        return orderLineShipAlone;
    }

    /**
     * Sets the value of the orderLineShipAlone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineShipAlone(String value) {
        this.orderLineShipAlone = value;
    }

    /**
     * Gets the value of the orderLineShipWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineShipWeight() {
        return orderLineShipWeight;
    }

    /**
     * Sets the value of the orderLineShipWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineShipWeight(BigDecimal value) {
        this.orderLineShipWeight = value;
    }

    /**
     * Gets the value of the orderLineMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineMessage() {
        return orderLineMessage;
    }

    /**
     * Sets the value of the orderLineMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineMessage(String value) {
        this.orderLineMessage = value;
    }

    /**
     * Gets the value of the customizations property.
     * 
     * @return
     *     possible object is
     *     {@link DSSalesOrderCustomizationsTypeBean }
     *     
     */
    public DSSalesOrderCustomizationsTypeBean getCustomizations() {
        return customizations;
    }

    /**
     * Sets the value of the customizations property.
     * 
     * @param value
     *     allowed object is
     *     {@link DSSalesOrderCustomizationsTypeBean }
     *     
     */
    public void setCustomizations(DSSalesOrderCustomizationsTypeBean value) {
        this.customizations = value;
    }

    /**
     * Gets the value of the requestingSystemLineNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestingSystemLineNo() {
        return requestingSystemLineNo;
    }

    /**
     * Sets the value of the requestingSystemLineNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestingSystemLineNo(String value) {
        this.requestingSystemLineNo = value;
    }

    /**
     * Gets the value of the lineItemStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineItemStatus() {
        return lineItemStatus;
    }

    /**
     * Sets the value of the lineItemStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineItemStatus(String value) {
        this.lineItemStatus = value;
    }

    /**
     * Gets the value of the lineItemNo property.
     * 
     */
    public int getLineItemNo() {
        return lineItemNo;
    }

    /**
     * Sets the value of the lineItemNo property.
     * 
     */
    public void setLineItemNo(int value) {
        this.lineItemNo = value;
    }

}
