
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderUpdateResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderUpdateResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order_update_response_message" type="{http://microsretail.com/Locate}OrderUpdateResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderUpdateResponse", propOrder = {
    "orderUpdateResponseMessage"
})
public class OrderUpdateResponse {

    @XmlElement(name = "order_update_response_message")
    protected OrderUpdateResponseMessageTypeBean orderUpdateResponseMessage;

    /**
     * Gets the value of the orderUpdateResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link OrderUpdateResponseMessageTypeBean }
     *     
     */
    public OrderUpdateResponseMessageTypeBean getOrderUpdateResponseMessage() {
        return orderUpdateResponseMessage;
    }

    /**
     * Sets the value of the orderUpdateResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderUpdateResponseMessageTypeBean }
     *     
     */
    public void setOrderUpdateResponseMessage(OrderUpdateResponseMessageTypeBean value) {
        this.orderUpdateResponseMessage = value;
    }

}
