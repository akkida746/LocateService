
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateRequestMessageSystemProductTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateRequestMessageSystemProductTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="description" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="department" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="class" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="sub_class" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="master_style_code" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="product_locations" type="{http://microsretail.com/Locate}ProductUpdateRequestMessageProductLocationsTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="system_code" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="system_product_code" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="product_code" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateRequestMessageSystemProductTypeBean", propOrder = {
    "description",
    "department",
    "clazz",
    "subClass",
    "masterStyleCode",
    "productLocations"
})
public class ProductUpdateRequestMessageSystemProductTypeBean {

    @XmlElement(required = true)
    protected String description;
    @XmlElement(required = true)
    protected String department;
    @XmlElement(name = "class", required = true)
    protected String clazz;
    @XmlElement(name = "sub_class", required = true)
    protected String subClass;
    @XmlElement(name = "master_style_code", required = true)
    protected String masterStyleCode;
    @XmlElement(name = "product_locations")
    protected ProductUpdateRequestMessageProductLocationsTypeBean productLocations;
    @XmlAttribute(name = "system_code", required = true)
    protected String systemCode;
    @XmlAttribute(name = "system_product_code", required = true)
    protected String systemProductCode;
    @XmlAttribute(name = "product_code", required = true)
    protected String productCode;

    /**
     * Gets the value of the description property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDescription() {
        return description;
    }

    /**
     * Sets the value of the description property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDescription(String value) {
        this.description = value;
    }

    /**
     * Gets the value of the department property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment() {
        return department;
    }

    /**
     * Sets the value of the department property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment(String value) {
        this.department = value;
    }

    /**
     * Gets the value of the clazz property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getClazz() {
        return clazz;
    }

    /**
     * Sets the value of the clazz property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setClazz(String value) {
        this.clazz = value;
    }

    /**
     * Gets the value of the subClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSubClass() {
        return subClass;
    }

    /**
     * Sets the value of the subClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSubClass(String value) {
        this.subClass = value;
    }

    /**
     * Gets the value of the masterStyleCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMasterStyleCode() {
        return masterStyleCode;
    }

    /**
     * Sets the value of the masterStyleCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMasterStyleCode(String value) {
        this.masterStyleCode = value;
    }

    /**
     * Gets the value of the productLocations property.
     * 
     * @return
     *     possible object is
     *     {@link ProductUpdateRequestMessageProductLocationsTypeBean }
     *     
     */
    public ProductUpdateRequestMessageProductLocationsTypeBean getProductLocations() {
        return productLocations;
    }

    /**
     * Sets the value of the productLocations property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductUpdateRequestMessageProductLocationsTypeBean }
     *     
     */
    public void setProductLocations(ProductUpdateRequestMessageProductLocationsTypeBean value) {
        this.productLocations = value;
    }

    /**
     * Gets the value of the systemCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemCode() {
        return systemCode;
    }

    /**
     * Sets the value of the systemCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemCode(String value) {
        this.systemCode = value;
    }

    /**
     * Gets the value of the systemProductCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSystemProductCode() {
        return systemProductCode;
    }

    /**
     * Sets the value of the systemProductCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSystemProductCode(String value) {
        this.systemProductCode = value;
    }

    /**
     * Gets the value of the productCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getProductCode() {
        return productCode;
    }

    /**
     * Sets the value of the productCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setProductCode(String value) {
        this.productCode = value;
    }

}
