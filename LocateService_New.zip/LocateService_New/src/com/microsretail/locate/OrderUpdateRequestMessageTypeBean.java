
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderUpdateRequestMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderUpdateRequestMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}OrderUpdateRequestMessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}OrderUpdateRequestMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderUpdateRequestMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class OrderUpdateRequestMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected OrderUpdateRequestMessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected OrderUpdateRequestMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link OrderUpdateRequestMessageHeaderTypeBean }
     *     
     */
    public OrderUpdateRequestMessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderUpdateRequestMessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(OrderUpdateRequestMessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link OrderUpdateRequestMessageBodyTypeBean }
     *     
     */
    public OrderUpdateRequestMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderUpdateRequestMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(OrderUpdateRequestMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
