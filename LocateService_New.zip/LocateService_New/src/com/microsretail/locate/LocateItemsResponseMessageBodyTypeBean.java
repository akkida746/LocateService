
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocateItemsResponseMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocateItemsResponseMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}LocateItemsResponseMessageItemsTypeBean"/&gt;
 *         &lt;element name="locations" type="{http://microsretail.com/Locate}LocateItemsResponseMessageLocationsTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="split_order" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocateItemsResponseMessageBodyTypeBean", propOrder = {
    "items",
    "locations"
})
public class LocateItemsResponseMessageBodyTypeBean {

    @XmlElement(required = true)
    protected LocateItemsResponseMessageItemsTypeBean items;
    @XmlElement(required = true)
    protected LocateItemsResponseMessageLocationsTypeBean locations;
    @XmlAttribute(name = "split_order")
    protected String splitOrder;
    @XmlAttribute(name = "request_id")
    protected String requestId;

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsResponseMessageItemsTypeBean }
     *     
     */
    public LocateItemsResponseMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsResponseMessageItemsTypeBean }
     *     
     */
    public void setItems(LocateItemsResponseMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the locations property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsResponseMessageLocationsTypeBean }
     *     
     */
    public LocateItemsResponseMessageLocationsTypeBean getLocations() {
        return locations;
    }

    /**
     * Sets the value of the locations property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsResponseMessageLocationsTypeBean }
     *     
     */
    public void setLocations(LocateItemsResponseMessageLocationsTypeBean value) {
        this.locations = value;
    }

    /**
     * Gets the value of the splitOrder property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSplitOrder() {
        return splitOrder;
    }

    /**
     * Sets the value of the splitOrder property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSplitOrder(String value) {
        this.splitOrder = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

}
