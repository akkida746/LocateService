
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateResponseMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateResponseMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="response_cd" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="response_description" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateResponseMessageBodyTypeBean", propOrder = {
    "responseCd",
    "responseDescription"
})
public class ProductUpdateResponseMessageBodyTypeBean {

    @XmlElement(name = "response_cd", required = true)
    protected String responseCd;
    @XmlElement(name = "response_description", required = true)
    protected String responseDescription;

    /**
     * Gets the value of the responseCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseCd() {
        return responseCd;
    }

    /**
     * Sets the value of the responseCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseCd(String value) {
        this.responseCd = value;
    }

    /**
     * Gets the value of the responseDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseDescription() {
        return responseDescription;
    }

    /**
     * Sets the value of the responseDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseDescription(String value) {
        this.responseDescription = value;
    }

}
