
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusInquiryRequestMessageLookupDataTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusInquiryRequestMessageLookupDataTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="employee_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}StatusInquiryRequestMessageStoreLocationTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="order_id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusInquiryRequestMessageLookupDataTypeBean", propOrder = {
    "refTransactionNo",
    "employeeId",
    "storeLocation"
})
public class StatusInquiryRequestMessageLookupDataTypeBean {

    @XmlElement(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlElement(name = "employee_id", required = true)
    protected String employeeId;
    @XmlElement(name = "store_location", required = true)
    protected StatusInquiryRequestMessageStoreLocationTypeBean storeLocation;
    @XmlAttribute(name = "order_id")
    protected String orderId;
    @XmlAttribute(name = "request_id")
    protected String requestId;

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the employeeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the value of the employeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeId(String value) {
        this.employeeId = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInquiryRequestMessageStoreLocationTypeBean }
     *     
     */
    public StatusInquiryRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInquiryRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(StatusInquiryRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

}
