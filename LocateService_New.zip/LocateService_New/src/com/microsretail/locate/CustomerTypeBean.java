
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSeeAlso;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for customerTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="customerTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="name" type="{http://microsretail.com/Locate}NameTypeBean"/&gt;
 *         &lt;element name="address" type="{http://microsretail.com/Locate}AddressTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "customerTypeBean", propOrder = {
    "name",
    "address"
})
@XmlSeeAlso({
    SoldToCustomerTypeBean.class
})
public class CustomerTypeBean {

    @XmlElement(required = true)
    protected NameTypeBean name;
    @XmlElement(required = true)
    protected AddressTypeBean address;

    /**
     * Gets the value of the name property.
     * 
     * @return
     *     possible object is
     *     {@link NameTypeBean }
     *     
     */
    public NameTypeBean getName() {
        return name;
    }

    /**
     * Sets the value of the name property.
     * 
     * @param value
     *     allowed object is
     *     {@link NameTypeBean }
     *     
     */
    public void setName(NameTypeBean value) {
        this.name = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link AddressTypeBean }
     *     
     */
    public AddressTypeBean getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link AddressTypeBean }
     *     
     */
    public void setAddress(AddressTypeBean value) {
        this.address = value;
    }

}
