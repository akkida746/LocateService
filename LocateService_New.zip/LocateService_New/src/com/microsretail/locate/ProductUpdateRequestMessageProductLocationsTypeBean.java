
package com.microsretail.locate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateRequestMessageProductLocationsTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateRequestMessageProductLocationsTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="product_location" type="{http://microsretail.com/Locate}ProductUpdateRequestMessageProductLocationTypeBean" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateRequestMessageProductLocationsTypeBean", propOrder = {
    "productLocation"
})
public class ProductUpdateRequestMessageProductLocationsTypeBean {

    @XmlElement(name = "product_location", required = true)
    protected List<ProductUpdateRequestMessageProductLocationTypeBean> productLocation;

    /**
     * Gets the value of the productLocation property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the productLocation property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getProductLocation().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ProductUpdateRequestMessageProductLocationTypeBean }
     * 
     * 
     */
    public List<ProductUpdateRequestMessageProductLocationTypeBean> getProductLocation() {
        if (productLocation == null) {
            productLocation = new ArrayList<ProductUpdateRequestMessageProductLocationTypeBean>();
        }
        return this.productLocation;
    }

}
