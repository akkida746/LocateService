
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SubmitOrderResponseMessageFulfillmentDetail complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubmitOrderResponseMessageFulfillmentDetail"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="fulfillment_qty" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="fulfillment_location_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fulfillment_system_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="requesting_system_line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubmitOrderResponseMessageFulfillmentDetail")
public class SubmitOrderResponseMessageFulfillmentDetail {

    @XmlAttribute(name = "fulfillment_qty", required = true)
    protected int fulfillmentQty;
    @XmlAttribute(name = "fulfillment_location_cd")
    protected String fulfillmentLocationCd;
    @XmlAttribute(name = "fulfillment_system_cd")
    protected String fulfillmentSystemCd;
    @XmlAttribute(name = "item_id", required = true)
    protected String itemId;
    @XmlAttribute(name = "requesting_system_line_no", required = true)
    protected int requestingSystemLineNo;
    @XmlAttribute(name = "line_no", required = true)
    protected int lineNo;

    /**
     * Gets the value of the fulfillmentQty property.
     * 
     */
    public int getFulfillmentQty() {
        return fulfillmentQty;
    }

    /**
     * Sets the value of the fulfillmentQty property.
     * 
     */
    public void setFulfillmentQty(int value) {
        this.fulfillmentQty = value;
    }

    /**
     * Gets the value of the fulfillmentLocationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillmentLocationCd() {
        return fulfillmentLocationCd;
    }

    /**
     * Sets the value of the fulfillmentLocationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillmentLocationCd(String value) {
        this.fulfillmentLocationCd = value;
    }

    /**
     * Gets the value of the fulfillmentSystemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillmentSystemCd() {
        return fulfillmentSystemCd;
    }

    /**
     * Sets the value of the fulfillmentSystemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillmentSystemCd(String value) {
        this.fulfillmentSystemCd = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the requestingSystemLineNo property.
     * 
     */
    public int getRequestingSystemLineNo() {
        return requestingSystemLineNo;
    }

    /**
     * Sets the value of the requestingSystemLineNo property.
     * 
     */
    public void setRequestingSystemLineNo(int value) {
        this.requestingSystemLineNo = value;
    }

    /**
     * Gets the value of the lineNo property.
     * 
     */
    public int getLineNo() {
        return lineNo;
    }

    /**
     * Sets the value of the lineNo property.
     * 
     */
    public void setLineNo(int value) {
        this.lineNo = value;
    }

}
