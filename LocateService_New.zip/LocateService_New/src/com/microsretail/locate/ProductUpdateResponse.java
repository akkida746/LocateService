
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="product_update_response_message" type="{http://microsretail.com/Locate}ProductUpdateResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateResponse", propOrder = {
    "productUpdateResponseMessage"
})
public class ProductUpdateResponse {

    @XmlElement(name = "product_update_response_message")
    protected ProductUpdateResponseMessageTypeBean productUpdateResponseMessage;

    /**
     * Gets the value of the productUpdateResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link ProductUpdateResponseMessageTypeBean }
     *     
     */
    public ProductUpdateResponseMessageTypeBean getProductUpdateResponseMessage() {
        return productUpdateResponseMessage;
    }

    /**
     * Sets the value of the productUpdateResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductUpdateResponseMessageTypeBean }
     *     
     */
    public void setProductUpdateResponseMessage(ProductUpdateResponseMessageTypeBean value) {
        this.productUpdateResponseMessage = value;
    }

}
