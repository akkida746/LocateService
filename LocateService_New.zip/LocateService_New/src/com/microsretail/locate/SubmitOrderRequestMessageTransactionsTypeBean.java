
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SubmitOrderRequestMessageTransactionsTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SubmitOrderRequestMessageTransactionsTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="transaction_header" type="{http://microsretail.com/Locate}SubmitOrderRequestMessageTransactionHeaderTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SubmitOrderRequestMessageTransactionsTypeBean", propOrder = {
    "transactionHeader"
})
public class SubmitOrderRequestMessageTransactionsTypeBean {

    @XmlElement(name = "transaction_header", required = true)
    protected SubmitOrderRequestMessageTransactionHeaderTypeBean transactionHeader;

    /**
     * Gets the value of the transactionHeader property.
     * 
     * @return
     *     possible object is
     *     {@link SubmitOrderRequestMessageTransactionHeaderTypeBean }
     *     
     */
    public SubmitOrderRequestMessageTransactionHeaderTypeBean getTransactionHeader() {
        return transactionHeader;
    }

    /**
     * Sets the value of the transactionHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link SubmitOrderRequestMessageTransactionHeaderTypeBean }
     *     
     */
    public void setTransactionHeader(SubmitOrderRequestMessageTransactionHeaderTypeBean value) {
        this.transactionHeader = value;
    }

}
