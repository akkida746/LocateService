
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusUpdateRequestMessageItemTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusUpdateRequestMessageItemTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ship_to" type="{http://microsretail.com/Locate}customerTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="item_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_qty" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="shipping_agent" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="tracking_number" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fulfilling_location_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fulfilling_system_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="requesting_system_line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="status_date" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_status_reason_code" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_status_reason_note" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusUpdateRequestMessageItemTypeBean", propOrder = {
    "shipTo"
})
public class StatusUpdateRequestMessageItemTypeBean {

    @XmlElement(name = "ship_to")
    protected CustomerTypeBean shipTo;
    @XmlAttribute(name = "item_id", required = true)
    protected String itemId;
    @XmlAttribute(name = "item_qty", required = true)
    protected int itemQty;
    @XmlAttribute(name = "shipping_agent", required = true)
    protected String shippingAgent;
    @XmlAttribute(name = "tracking_number", required = true)
    protected String trackingNumber;
    @XmlAttribute(name = "item_status", required = true)
    protected String itemStatus;
    @XmlAttribute(name = "fulfilling_location_cd")
    protected String fulfillingLocationCd;
    @XmlAttribute(name = "fulfilling_system_cd")
    protected String fulfillingSystemCd;
    @XmlAttribute(name = "line_no", required = true)
    protected int lineNo;
    @XmlAttribute(name = "requesting_system_line_no", required = true)
    protected int requestingSystemLineNo;
    @XmlAttribute(name = "status_date")
    protected String statusDate;
    @XmlAttribute(name = "item_status_reason_code")
    protected String itemStatusReasonCode;
    @XmlAttribute(name = "item_status_reason_note")
    protected String itemStatusReasonNote;

    /**
     * Gets the value of the shipTo property.
     * 
     * @return
     *     possible object is
     *     {@link CustomerTypeBean }
     *     
     */
    public CustomerTypeBean getShipTo() {
        return shipTo;
    }

    /**
     * Sets the value of the shipTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link CustomerTypeBean }
     *     
     */
    public void setShipTo(CustomerTypeBean value) {
        this.shipTo = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the itemQty property.
     * 
     */
    public int getItemQty() {
        return itemQty;
    }

    /**
     * Sets the value of the itemQty property.
     * 
     */
    public void setItemQty(int value) {
        this.itemQty = value;
    }

    /**
     * Gets the value of the shippingAgent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShippingAgent() {
        return shippingAgent;
    }

    /**
     * Sets the value of the shippingAgent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShippingAgent(String value) {
        this.shippingAgent = value;
    }

    /**
     * Gets the value of the trackingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingNumber() {
        return trackingNumber;
    }

    /**
     * Sets the value of the trackingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingNumber(String value) {
        this.trackingNumber = value;
    }

    /**
     * Gets the value of the itemStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemStatus() {
        return itemStatus;
    }

    /**
     * Sets the value of the itemStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemStatus(String value) {
        this.itemStatus = value;
    }

    /**
     * Gets the value of the fulfillingLocationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillingLocationCd() {
        return fulfillingLocationCd;
    }

    /**
     * Sets the value of the fulfillingLocationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillingLocationCd(String value) {
        this.fulfillingLocationCd = value;
    }

    /**
     * Gets the value of the fulfillingSystemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillingSystemCd() {
        return fulfillingSystemCd;
    }

    /**
     * Sets the value of the fulfillingSystemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillingSystemCd(String value) {
        this.fulfillingSystemCd = value;
    }

    /**
     * Gets the value of the lineNo property.
     * 
     */
    public int getLineNo() {
        return lineNo;
    }

    /**
     * Sets the value of the lineNo property.
     * 
     */
    public void setLineNo(int value) {
        this.lineNo = value;
    }

    /**
     * Gets the value of the requestingSystemLineNo property.
     * 
     */
    public int getRequestingSystemLineNo() {
        return requestingSystemLineNo;
    }

    /**
     * Sets the value of the requestingSystemLineNo property.
     * 
     */
    public void setRequestingSystemLineNo(int value) {
        this.requestingSystemLineNo = value;
    }

    /**
     * Gets the value of the statusDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDate() {
        return statusDate;
    }

    /**
     * Sets the value of the statusDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDate(String value) {
        this.statusDate = value;
    }

    /**
     * Gets the value of the itemStatusReasonCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemStatusReasonCode() {
        return itemStatusReasonCode;
    }

    /**
     * Sets the value of the itemStatusReasonCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemStatusReasonCode(String value) {
        this.itemStatusReasonCode = value;
    }

    /**
     * Gets the value of the itemStatusReasonNote property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemStatusReasonNote() {
        return itemStatusReasonNote;
    }

    /**
     * Sets the value of the itemStatusReasonNote property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemStatusReasonNote(String value) {
        this.itemStatusReasonNote = value;
    }

}
