
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusInquiryRequestMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusInquiryRequestMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}StatusInquiryRequestMessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}StatusInquiryRequestMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusInquiryRequestMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class StatusInquiryRequestMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected StatusInquiryRequestMessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected StatusInquiryRequestMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInquiryRequestMessageHeaderTypeBean }
     *     
     */
    public StatusInquiryRequestMessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInquiryRequestMessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(StatusInquiryRequestMessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInquiryRequestMessageBodyTypeBean }
     *     
     */
    public StatusInquiryRequestMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInquiryRequestMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(StatusInquiryRequestMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
