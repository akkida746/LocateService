
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderSearchRequestMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderSearchRequestMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}OrderSearchMessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}OrderSearchRequestMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderSearchRequestMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class OrderSearchRequestMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected OrderSearchMessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected OrderSearchRequestMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link OrderSearchMessageHeaderTypeBean }
     *     
     */
    public OrderSearchMessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderSearchMessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(OrderSearchMessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link OrderSearchRequestMessageBodyTypeBean }
     *     
     */
    public OrderSearchRequestMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderSearchRequestMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(OrderSearchRequestMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
