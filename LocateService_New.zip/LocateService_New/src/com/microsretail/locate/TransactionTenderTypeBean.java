
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for TransactionTenderTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="TransactionTenderTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="tender_description" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="tender_amount" type="{http://www.w3.org/2001/XMLSchema}decimal"/&gt;
 *         &lt;element name="tender_account" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="line_item_no" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "TransactionTenderTypeBean", propOrder = {
    "tenderDescription",
    "tenderAmount",
    "tenderAccount"
})
public class TransactionTenderTypeBean {

    @XmlElement(name = "tender_description", required = true)
    protected String tenderDescription;
    @XmlElement(name = "tender_amount", required = true)
    protected BigDecimal tenderAmount;
    @XmlElement(name = "tender_account")
    protected String tenderAccount;
    @XmlAttribute(name = "line_item_no", required = true)
    protected String lineItemNo;

    /**
     * Gets the value of the tenderDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenderDescription() {
        return tenderDescription;
    }

    /**
     * Sets the value of the tenderDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenderDescription(String value) {
        this.tenderDescription = value;
    }

    /**
     * Gets the value of the tenderAmount property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getTenderAmount() {
        return tenderAmount;
    }

    /**
     * Sets the value of the tenderAmount property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setTenderAmount(BigDecimal value) {
        this.tenderAmount = value;
    }

    /**
     * Gets the value of the tenderAccount property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTenderAccount() {
        return tenderAccount;
    }

    /**
     * Sets the value of the tenderAccount property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTenderAccount(String value) {
        this.tenderAccount = value;
    }

    /**
     * Gets the value of the lineItemNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLineItemNo() {
        return lineItemNo;
    }

    /**
     * Sets the value of the lineItemNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLineItemNo(String value) {
        this.lineItemNo = value;
    }

}
