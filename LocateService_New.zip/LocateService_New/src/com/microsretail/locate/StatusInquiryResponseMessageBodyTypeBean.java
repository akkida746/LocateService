
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusInquiryResponseMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusInquiryResponseMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="orders" type="{http://microsretail.com/Locate}StatusInquiryResponseMessageOrdersTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusInquiryResponseMessageBodyTypeBean", propOrder = {
    "orders"
})
public class StatusInquiryResponseMessageBodyTypeBean {

    protected StatusInquiryResponseMessageOrdersTypeBean orders;

    /**
     * Gets the value of the orders property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInquiryResponseMessageOrdersTypeBean }
     *     
     */
    public StatusInquiryResponseMessageOrdersTypeBean getOrders() {
        return orders;
    }

    /**
     * Sets the value of the orders property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInquiryResponseMessageOrdersTypeBean }
     *     
     */
    public void setOrders(StatusInquiryResponseMessageOrdersTypeBean value) {
        this.orders = value;
    }

}
