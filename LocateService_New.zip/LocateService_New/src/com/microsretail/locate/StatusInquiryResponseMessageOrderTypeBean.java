
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusInquiryResponseMessageOrderTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusInquiryResponseMessageOrderTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order_type" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}StatusInquiryResponseMessageItemsTypeBean" minOccurs="0"/&gt;
 *         &lt;element name="sold_to_customer" type="{http://microsretail.com/Locate}SoldToCustomerTypeBean" minOccurs="0"/&gt;
 *         &lt;element name="transaction_tenders" type="{http://microsretail.com/Locate}TransactionTendersTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="currency" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="balance_due" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="freight" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="source_code" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="gift" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_via_description" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_via" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="special_instructions" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="transaction_total" use="required" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="transaction_tax" use="required" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="transaction_subtotal" use="required" type="{http://www.w3.org/2001/XMLSchema}double" /&gt;
 *       &lt;attribute name="order_date" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_location_description" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_location_cd" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_system_cd" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="under_review" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_additional_freight_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_additional_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="ship_complete" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="freight_tax" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_message" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="gift_message" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusInquiryResponseMessageOrderTypeBean", propOrder = {
    "orderType",
    "items",
    "soldToCustomer",
    "transactionTenders"
})
public class StatusInquiryResponseMessageOrderTypeBean {

    @XmlElement(name = "order_type")
    protected int orderType;
    protected StatusInquiryResponseMessageItemsTypeBean items;
    @XmlElement(name = "sold_to_customer")
    protected SoldToCustomerTypeBean soldToCustomer;
    @XmlElement(name = "transaction_tenders")
    protected TransactionTendersTypeBean transactionTenders;
    @XmlAttribute(name = "currency")
    protected String currency;
    @XmlAttribute(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlAttribute(name = "balance_due")
    protected Double balanceDue;
    @XmlAttribute(name = "freight")
    protected Double freight;
    @XmlAttribute(name = "source_code")
    protected String sourceCode;
    @XmlAttribute(name = "gift")
    protected String gift;
    @XmlAttribute(name = "ship_via_description")
    protected String shipViaDescription;
    @XmlAttribute(name = "ship_via")
    protected String shipVia;
    @XmlAttribute(name = "special_instructions")
    protected String specialInstructions;
    @XmlAttribute(name = "transaction_total", required = true)
    protected double transactionTotal;
    @XmlAttribute(name = "transaction_tax", required = true)
    protected double transactionTax;
    @XmlAttribute(name = "transaction_subtotal", required = true)
    protected double transactionSubtotal;
    @XmlAttribute(name = "order_date", required = true)
    protected String orderDate;
    @XmlAttribute(name = "originating_location_description", required = true)
    protected String originatingLocationDescription;
    @XmlAttribute(name = "originating_location_cd", required = true)
    protected String originatingLocationCd;
    @XmlAttribute(name = "originating_system_cd", required = true)
    protected String originatingSystemCd;
    @XmlAttribute(name = "order_status", required = true)
    protected String orderStatus;
    @XmlAttribute(name = "order_id", required = true)
    protected String orderId;
    @XmlAttribute(name = "request_id", required = true)
    protected int requestId;
    @XmlAttribute(name = "under_review")
    protected String underReview;
    @XmlAttribute(name = "order_additional_freight_charges")
    protected BigDecimal orderAdditionalFreightCharges;
    @XmlAttribute(name = "order_additional_charges")
    protected BigDecimal orderAdditionalCharges;
    @XmlAttribute(name = "ship_complete")
    protected String shipComplete;
    @XmlAttribute(name = "freight_tax")
    protected BigDecimal freightTax;
    @XmlAttribute(name = "order_message")
    protected String orderMessage;
    @XmlAttribute(name = "gift_message")
    protected String giftMessage;

    /**
     * Gets the value of the orderType property.
     * 
     */
    public int getOrderType() {
        return orderType;
    }

    /**
     * Sets the value of the orderType property.
     * 
     */
    public void setOrderType(int value) {
        this.orderType = value;
    }

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInquiryResponseMessageItemsTypeBean }
     *     
     */
    public StatusInquiryResponseMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInquiryResponseMessageItemsTypeBean }
     *     
     */
    public void setItems(StatusInquiryResponseMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the soldToCustomer property.
     * 
     * @return
     *     possible object is
     *     {@link SoldToCustomerTypeBean }
     *     
     */
    public SoldToCustomerTypeBean getSoldToCustomer() {
        return soldToCustomer;
    }

    /**
     * Sets the value of the soldToCustomer property.
     * 
     * @param value
     *     allowed object is
     *     {@link SoldToCustomerTypeBean }
     *     
     */
    public void setSoldToCustomer(SoldToCustomerTypeBean value) {
        this.soldToCustomer = value;
    }

    /**
     * Gets the value of the transactionTenders property.
     * 
     * @return
     *     possible object is
     *     {@link TransactionTendersTypeBean }
     *     
     */
    public TransactionTendersTypeBean getTransactionTenders() {
        return transactionTenders;
    }

    /**
     * Sets the value of the transactionTenders property.
     * 
     * @param value
     *     allowed object is
     *     {@link TransactionTendersTypeBean }
     *     
     */
    public void setTransactionTenders(TransactionTendersTypeBean value) {
        this.transactionTenders = value;
    }

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the balanceDue property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getBalanceDue() {
        return balanceDue;
    }

    /**
     * Sets the value of the balanceDue property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setBalanceDue(Double value) {
        this.balanceDue = value;
    }

    /**
     * Gets the value of the freight property.
     * 
     * @return
     *     possible object is
     *     {@link Double }
     *     
     */
    public Double getFreight() {
        return freight;
    }

    /**
     * Sets the value of the freight property.
     * 
     * @param value
     *     allowed object is
     *     {@link Double }
     *     
     */
    public void setFreight(Double value) {
        this.freight = value;
    }

    /**
     * Gets the value of the sourceCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSourceCode() {
        return sourceCode;
    }

    /**
     * Sets the value of the sourceCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSourceCode(String value) {
        this.sourceCode = value;
    }

    /**
     * Gets the value of the gift property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGift() {
        return gift;
    }

    /**
     * Sets the value of the gift property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGift(String value) {
        this.gift = value;
    }

    /**
     * Gets the value of the shipViaDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipViaDescription() {
        return shipViaDescription;
    }

    /**
     * Sets the value of the shipViaDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipViaDescription(String value) {
        this.shipViaDescription = value;
    }

    /**
     * Gets the value of the shipVia property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipVia() {
        return shipVia;
    }

    /**
     * Sets the value of the shipVia property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipVia(String value) {
        this.shipVia = value;
    }

    /**
     * Gets the value of the specialInstructions property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSpecialInstructions() {
        return specialInstructions;
    }

    /**
     * Sets the value of the specialInstructions property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSpecialInstructions(String value) {
        this.specialInstructions = value;
    }

    /**
     * Gets the value of the transactionTotal property.
     * 
     */
    public double getTransactionTotal() {
        return transactionTotal;
    }

    /**
     * Sets the value of the transactionTotal property.
     * 
     */
    public void setTransactionTotal(double value) {
        this.transactionTotal = value;
    }

    /**
     * Gets the value of the transactionTax property.
     * 
     */
    public double getTransactionTax() {
        return transactionTax;
    }

    /**
     * Sets the value of the transactionTax property.
     * 
     */
    public void setTransactionTax(double value) {
        this.transactionTax = value;
    }

    /**
     * Gets the value of the transactionSubtotal property.
     * 
     */
    public double getTransactionSubtotal() {
        return transactionSubtotal;
    }

    /**
     * Sets the value of the transactionSubtotal property.
     * 
     */
    public void setTransactionSubtotal(double value) {
        this.transactionSubtotal = value;
    }

    /**
     * Gets the value of the orderDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the value of the orderDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderDate(String value) {
        this.orderDate = value;
    }

    /**
     * Gets the value of the originatingLocationDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingLocationDescription() {
        return originatingLocationDescription;
    }

    /**
     * Sets the value of the originatingLocationDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingLocationDescription(String value) {
        this.originatingLocationDescription = value;
    }

    /**
     * Gets the value of the originatingLocationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingLocationCd() {
        return originatingLocationCd;
    }

    /**
     * Sets the value of the originatingLocationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingLocationCd(String value) {
        this.originatingLocationCd = value;
    }

    /**
     * Gets the value of the originatingSystemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingSystemCd() {
        return originatingSystemCd;
    }

    /**
     * Sets the value of the originatingSystemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingSystemCd(String value) {
        this.originatingSystemCd = value;
    }

    /**
     * Gets the value of the orderStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderStatus() {
        return orderStatus;
    }

    /**
     * Sets the value of the orderStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderStatus(String value) {
        this.orderStatus = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     */
    public int getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     */
    public void setRequestId(int value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the underReview property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderReview() {
        return underReview;
    }

    /**
     * Sets the value of the underReview property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderReview(String value) {
        this.underReview = value;
    }

    /**
     * Gets the value of the orderAdditionalFreightCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalFreightCharges() {
        return orderAdditionalFreightCharges;
    }

    /**
     * Sets the value of the orderAdditionalFreightCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalFreightCharges(BigDecimal value) {
        this.orderAdditionalFreightCharges = value;
    }

    /**
     * Gets the value of the orderAdditionalCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalCharges() {
        return orderAdditionalCharges;
    }

    /**
     * Sets the value of the orderAdditionalCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalCharges(BigDecimal value) {
        this.orderAdditionalCharges = value;
    }

    /**
     * Gets the value of the shipComplete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipComplete() {
        return shipComplete;
    }

    /**
     * Sets the value of the shipComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipComplete(String value) {
        this.shipComplete = value;
    }

    /**
     * Gets the value of the freightTax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFreightTax() {
        return freightTax;
    }

    /**
     * Sets the value of the freightTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFreightTax(BigDecimal value) {
        this.freightTax = value;
    }

    /**
     * Gets the value of the orderMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderMessage() {
        return orderMessage;
    }

    /**
     * Sets the value of the orderMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderMessage(String value) {
        this.orderMessage = value;
    }

    /**
     * Gets the value of the giftMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftMessage() {
        return giftMessage;
    }

    /**
     * Sets the value of the giftMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftMessage(String value) {
        this.giftMessage = value;
    }

}
