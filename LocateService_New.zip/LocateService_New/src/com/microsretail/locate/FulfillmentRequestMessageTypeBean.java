
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FulfillmentRequestMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FulfillmentRequestMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}FulfillmentRequestMessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}FulfillmentRequestMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FulfillmentRequestMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class FulfillmentRequestMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected FulfillmentRequestMessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected FulfillmentRequestMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentRequestMessageHeaderTypeBean }
     *     
     */
    public FulfillmentRequestMessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentRequestMessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(FulfillmentRequestMessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentRequestMessageBodyTypeBean }
     *     
     */
    public FulfillmentRequestMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentRequestMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(FulfillmentRequestMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
