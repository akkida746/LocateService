
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusUpdateResponseMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusUpdateResponseMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}MessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}StatusUpdateResponseMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusUpdateResponseMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class StatusUpdateResponseMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected MessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected StatusUpdateResponseMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link MessageHeaderTypeBean }
     *     
     */
    public MessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link MessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(MessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link StatusUpdateResponseMessageBodyTypeBean }
     *     
     */
    public StatusUpdateResponseMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusUpdateResponseMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(StatusUpdateResponseMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
