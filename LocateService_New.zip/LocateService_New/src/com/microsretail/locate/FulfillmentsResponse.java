
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FulfillmentsResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FulfillmentsResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fulfillment_response_message" type="{http://microsretail.com/Locate}FulfillmentResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FulfillmentsResponse", propOrder = {
    "fulfillmentResponseMessage"
})
public class FulfillmentsResponse {

    @XmlElement(name = "fulfillment_response_message")
    protected FulfillmentResponseMessageTypeBean fulfillmentResponseMessage;

    /**
     * Gets the value of the fulfillmentResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentResponseMessageTypeBean }
     *     
     */
    public FulfillmentResponseMessageTypeBean getFulfillmentResponseMessage() {
        return fulfillmentResponseMessage;
    }

    /**
     * Sets the value of the fulfillmentResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentResponseMessageTypeBean }
     *     
     */
    public void setFulfillmentResponseMessage(FulfillmentResponseMessageTypeBean value) {
        this.fulfillmentResponseMessage = value;
    }

}
