
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusListInquiryResponseMessageOrderTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusListInquiryResponseMessageOrderTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order_type" type="{http://www.w3.org/2001/XMLSchema}int"/&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}StatusListInquiryResponseMessageItemsTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="order_action_response" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="order_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_system_cd" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_location_cd" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="originating_location_description" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_date" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="under_review" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_additional_freight_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_additional_charges" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="ship_complete" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="freight_tax" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_message" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="gift_message" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusListInquiryResponseMessageOrderTypeBean", propOrder = {
    "orderType",
    "items"
})
public class StatusListInquiryResponseMessageOrderTypeBean {

    @XmlElement(name = "order_type")
    protected int orderType;
    protected StatusListInquiryResponseMessageItemsTypeBean items;
    @XmlAttribute(name = "order_action_response")
    protected String orderActionResponse;
    @XmlAttribute(name = "request_id", required = true)
    protected int requestId;
    @XmlAttribute(name = "order_id", required = true)
    protected String orderId;
    @XmlAttribute(name = "order_status", required = true)
    protected String orderStatus;
    @XmlAttribute(name = "originating_system_cd", required = true)
    protected String originatingSystemCd;
    @XmlAttribute(name = "originating_location_cd", required = true)
    protected String originatingLocationCd;
    @XmlAttribute(name = "originating_location_description", required = true)
    protected String originatingLocationDescription;
    @XmlAttribute(name = "order_date", required = true)
    protected String orderDate;
    @XmlAttribute(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlAttribute(name = "under_review")
    protected String underReview;
    @XmlAttribute(name = "order_additional_freight_charges")
    protected BigDecimal orderAdditionalFreightCharges;
    @XmlAttribute(name = "order_additional_charges")
    protected BigDecimal orderAdditionalCharges;
    @XmlAttribute(name = "ship_complete")
    protected String shipComplete;
    @XmlAttribute(name = "freight_tax")
    protected BigDecimal freightTax;
    @XmlAttribute(name = "order_message")
    protected String orderMessage;
    @XmlAttribute(name = "gift_message")
    protected String giftMessage;

    /**
     * Gets the value of the orderType property.
     * 
     */
    public int getOrderType() {
        return orderType;
    }

    /**
     * Sets the value of the orderType property.
     * 
     */
    public void setOrderType(int value) {
        this.orderType = value;
    }

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryResponseMessageItemsTypeBean }
     *     
     */
    public StatusListInquiryResponseMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryResponseMessageItemsTypeBean }
     *     
     */
    public void setItems(StatusListInquiryResponseMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the orderActionResponse property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderActionResponse() {
        return orderActionResponse;
    }

    /**
     * Sets the value of the orderActionResponse property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderActionResponse(String value) {
        this.orderActionResponse = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     */
    public int getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     */
    public void setRequestId(int value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the orderStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderStatus() {
        return orderStatus;
    }

    /**
     * Sets the value of the orderStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderStatus(String value) {
        this.orderStatus = value;
    }

    /**
     * Gets the value of the originatingSystemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingSystemCd() {
        return originatingSystemCd;
    }

    /**
     * Sets the value of the originatingSystemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingSystemCd(String value) {
        this.originatingSystemCd = value;
    }

    /**
     * Gets the value of the originatingLocationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingLocationCd() {
        return originatingLocationCd;
    }

    /**
     * Sets the value of the originatingLocationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingLocationCd(String value) {
        this.originatingLocationCd = value;
    }

    /**
     * Gets the value of the originatingLocationDescription property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOriginatingLocationDescription() {
        return originatingLocationDescription;
    }

    /**
     * Sets the value of the originatingLocationDescription property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOriginatingLocationDescription(String value) {
        this.originatingLocationDescription = value;
    }

    /**
     * Gets the value of the orderDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the value of the orderDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderDate(String value) {
        this.orderDate = value;
    }

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the underReview property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUnderReview() {
        return underReview;
    }

    /**
     * Sets the value of the underReview property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUnderReview(String value) {
        this.underReview = value;
    }

    /**
     * Gets the value of the orderAdditionalFreightCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalFreightCharges() {
        return orderAdditionalFreightCharges;
    }

    /**
     * Sets the value of the orderAdditionalFreightCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalFreightCharges(BigDecimal value) {
        this.orderAdditionalFreightCharges = value;
    }

    /**
     * Gets the value of the orderAdditionalCharges property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderAdditionalCharges() {
        return orderAdditionalCharges;
    }

    /**
     * Sets the value of the orderAdditionalCharges property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderAdditionalCharges(BigDecimal value) {
        this.orderAdditionalCharges = value;
    }

    /**
     * Gets the value of the shipComplete property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipComplete() {
        return shipComplete;
    }

    /**
     * Sets the value of the shipComplete property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipComplete(String value) {
        this.shipComplete = value;
    }

    /**
     * Gets the value of the freightTax property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getFreightTax() {
        return freightTax;
    }

    /**
     * Sets the value of the freightTax property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setFreightTax(BigDecimal value) {
        this.freightTax = value;
    }

    /**
     * Gets the value of the orderMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderMessage() {
        return orderMessage;
    }

    /**
     * Sets the value of the orderMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderMessage(String value) {
        this.orderMessage = value;
    }

    /**
     * Gets the value of the giftMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getGiftMessage() {
        return giftMessage;
    }

    /**
     * Sets the value of the giftMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setGiftMessage(String value) {
        this.giftMessage = value;
    }

}
