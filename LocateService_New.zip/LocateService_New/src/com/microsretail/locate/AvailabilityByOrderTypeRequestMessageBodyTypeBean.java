
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AvailabilityByOrderTypeRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AvailabilityByOrderTypeRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="requesting_location" type="{http://microsretail.com/Locate}StoreLocationTypeBean"/&gt;
 *         &lt;element name="fulfillment_types" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean"/&gt;
 *         &lt;element name="items" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeRequestMessageItemsTypeBean"/&gt;
 *         &lt;element name="address" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeRequestMessageAddressTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AvailabilityByOrderTypeRequestMessageBodyTypeBean", propOrder = {
    "requestingLocation",
    "fulfillmentTypes",
    "items",
    "address"
})
public class AvailabilityByOrderTypeRequestMessageBodyTypeBean {

    @XmlElement(name = "requesting_location", required = true)
    protected StoreLocationTypeBean requestingLocation;
    @XmlElement(name = "fulfillment_types", required = true)
    protected AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean fulfillmentTypes;
    @XmlElement(required = true)
    protected AvailabilityByOrderTypeRequestMessageItemsTypeBean items;
    @XmlElement(required = true)
    protected AvailabilityByOrderTypeRequestMessageAddressTypeBean address;

    /**
     * Gets the value of the requestingLocation property.
     * 
     * @return
     *     possible object is
     *     {@link StoreLocationTypeBean }
     *     
     */
    public StoreLocationTypeBean getRequestingLocation() {
        return requestingLocation;
    }

    /**
     * Sets the value of the requestingLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link StoreLocationTypeBean }
     *     
     */
    public void setRequestingLocation(StoreLocationTypeBean value) {
        this.requestingLocation = value;
    }

    /**
     * Gets the value of the fulfillmentTypes property.
     * 
     * @return
     *     possible object is
     *     {@link AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean }
     *     
     */
    public AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean getFulfillmentTypes() {
        return fulfillmentTypes;
    }

    /**
     * Sets the value of the fulfillmentTypes property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean }
     *     
     */
    public void setFulfillmentTypes(AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean value) {
        this.fulfillmentTypes = value;
    }

    /**
     * Gets the value of the items property.
     * 
     * @return
     *     possible object is
     *     {@link AvailabilityByOrderTypeRequestMessageItemsTypeBean }
     *     
     */
    public AvailabilityByOrderTypeRequestMessageItemsTypeBean getItems() {
        return items;
    }

    /**
     * Sets the value of the items property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailabilityByOrderTypeRequestMessageItemsTypeBean }
     *     
     */
    public void setItems(AvailabilityByOrderTypeRequestMessageItemsTypeBean value) {
        this.items = value;
    }

    /**
     * Gets the value of the address property.
     * 
     * @return
     *     possible object is
     *     {@link AvailabilityByOrderTypeRequestMessageAddressTypeBean }
     *     
     */
    public AvailabilityByOrderTypeRequestMessageAddressTypeBean getAddress() {
        return address;
    }

    /**
     * Sets the value of the address property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailabilityByOrderTypeRequestMessageAddressTypeBean }
     *     
     */
    public void setAddress(AvailabilityByOrderTypeRequestMessageAddressTypeBean value) {
        this.address = value;
    }

}
