
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for LocateItemsRequestMessageTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="LocateItemsRequestMessageTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="message_header" type="{http://microsretail.com/Locate}LocateItemsRequestMessageHeaderTypeBean"/&gt;
 *         &lt;element name="message_body" type="{http://microsretail.com/Locate}LocateIemsRequestMessageBodyTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "LocateItemsRequestMessageTypeBean", propOrder = {
    "messageHeader",
    "messageBody"
})
public class LocateItemsRequestMessageTypeBean {

    @XmlElement(name = "message_header", required = true)
    protected LocateItemsRequestMessageHeaderTypeBean messageHeader;
    @XmlElement(name = "message_body", required = true)
    protected LocateIemsRequestMessageBodyTypeBean messageBody;

    /**
     * Gets the value of the messageHeader property.
     * 
     * @return
     *     possible object is
     *     {@link LocateItemsRequestMessageHeaderTypeBean }
     *     
     */
    public LocateItemsRequestMessageHeaderTypeBean getMessageHeader() {
        return messageHeader;
    }

    /**
     * Sets the value of the messageHeader property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateItemsRequestMessageHeaderTypeBean }
     *     
     */
    public void setMessageHeader(LocateItemsRequestMessageHeaderTypeBean value) {
        this.messageHeader = value;
    }

    /**
     * Gets the value of the messageBody property.
     * 
     * @return
     *     possible object is
     *     {@link LocateIemsRequestMessageBodyTypeBean }
     *     
     */
    public LocateIemsRequestMessageBodyTypeBean getMessageBody() {
        return messageBody;
    }

    /**
     * Sets the value of the messageBody property.
     * 
     * @param value
     *     allowed object is
     *     {@link LocateIemsRequestMessageBodyTypeBean }
     *     
     */
    public void setMessageBody(LocateIemsRequestMessageBodyTypeBean value) {
        this.messageBody = value;
    }

}
