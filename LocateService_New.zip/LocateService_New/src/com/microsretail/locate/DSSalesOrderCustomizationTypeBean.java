
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for DSSalesOrderCustomizationTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="DSSalesOrderCustomizationTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="customization_code" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="customization_message" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DSSalesOrderCustomizationTypeBean", propOrder = {
    "customizationCode",
    "customizationMessage"
})
public class DSSalesOrderCustomizationTypeBean {

    @XmlElement(name = "customization_code", required = true)
    protected String customizationCode;
    @XmlElement(name = "customization_message", required = true)
    protected String customizationMessage;

    /**
     * Gets the value of the customizationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomizationCode() {
        return customizationCode;
    }

    /**
     * Sets the value of the customizationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomizationCode(String value) {
        this.customizationCode = value;
    }

    /**
     * Gets the value of the customizationMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCustomizationMessage() {
        return customizationMessage;
    }

    /**
     * Sets the value of the customizationMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCustomizationMessage(String value) {
        this.customizationMessage = value;
    }

}
