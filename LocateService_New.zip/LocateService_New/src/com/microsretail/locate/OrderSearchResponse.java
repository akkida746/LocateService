
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderSearchResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderSearchResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order_search_response_message" type="{http://microsretail.com/Locate}StatusResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderSearchResponse", propOrder = {
    "orderSearchResponseMessage"
})
public class OrderSearchResponse {

    @XmlElement(name = "order_search_response_message")
    protected StatusResponseMessageTypeBean orderSearchResponseMessage;

    /**
     * Gets the value of the orderSearchResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link StatusResponseMessageTypeBean }
     *     
     */
    public StatusResponseMessageTypeBean getOrderSearchResponseMessage() {
        return orderSearchResponseMessage;
    }

    /**
     * Sets the value of the orderSearchResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusResponseMessageTypeBean }
     *     
     */
    public void setOrderSearchResponseMessage(StatusResponseMessageTypeBean value) {
        this.orderSearchResponseMessage = value;
    }

}
