
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateRequestMessageProductLocationTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateRequestMessageProductLocationTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="available_qty" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="next_po_qty" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="next_po_date" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="location_code" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateRequestMessageProductLocationTypeBean", propOrder = {
    "availableQty",
    "nextPoQty",
    "nextPoDate"
})
public class ProductUpdateRequestMessageProductLocationTypeBean {

    @XmlElement(name = "available_qty", required = true)
    protected String availableQty;
    @XmlElement(name = "next_po_qty", required = true)
    protected String nextPoQty;
    @XmlElement(name = "next_po_date", required = true)
    protected String nextPoDate;
    @XmlAttribute(name = "location_code", required = true)
    protected String locationCode;

    /**
     * Gets the value of the availableQty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getAvailableQty() {
        return availableQty;
    }

    /**
     * Sets the value of the availableQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setAvailableQty(String value) {
        this.availableQty = value;
    }

    /**
     * Gets the value of the nextPoQty property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextPoQty() {
        return nextPoQty;
    }

    /**
     * Sets the value of the nextPoQty property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextPoQty(String value) {
        this.nextPoQty = value;
    }

    /**
     * Gets the value of the nextPoDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getNextPoDate() {
        return nextPoDate;
    }

    /**
     * Sets the value of the nextPoDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setNextPoDate(String value) {
        this.nextPoDate = value;
    }

    /**
     * Gets the value of the locationCode property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getLocationCode() {
        return locationCode;
    }

    /**
     * Sets the value of the locationCode property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setLocationCode(String value) {
        this.locationCode = value;
    }

}
