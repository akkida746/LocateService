
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusListInquiryRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusListInquiryRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="lookup_data" type="{http://microsretail.com/Locate}StatusListInquiryRequestMessageLookupDataTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusListInquiryRequestMessageBodyTypeBean", propOrder = {
    "lookupData"
})
public class StatusListInquiryRequestMessageBodyTypeBean {

    @XmlElement(name = "lookup_data", required = true)
    protected StatusListInquiryRequestMessageLookupDataTypeBean lookupData;

    /**
     * Gets the value of the lookupData property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryRequestMessageLookupDataTypeBean }
     *     
     */
    public StatusListInquiryRequestMessageLookupDataTypeBean getLookupData() {
        return lookupData;
    }

    /**
     * Sets the value of the lookupData property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryRequestMessageLookupDataTypeBean }
     *     
     */
    public void setLookupData(StatusListInquiryRequestMessageLookupDataTypeBean value) {
        this.lookupData = value;
    }

}
