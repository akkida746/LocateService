
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusListInquiryRequestMessageLookupDataTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusListInquiryRequestMessageLookupDataTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="employee_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}StatusListInquiryRequestMessageStoreLocationTypeBean"/&gt;
 *         &lt;element name="request_ids" type="{http://microsretail.com/Locate}StatusListInquiryRequestMessageRequestIdsBean"/&gt;
 *         &lt;element name="statuses" type="{http://microsretail.com/Locate}StatusListInquiryRequestMessageStatusesBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="response_type" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="status_condition" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusListInquiryRequestMessageLookupDataTypeBean", propOrder = {
    "refTransactionNo",
    "employeeId",
    "storeLocation",
    "requestIds",
    "statuses"
})
public class StatusListInquiryRequestMessageLookupDataTypeBean {

    @XmlElement(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlElement(name = "employee_id", required = true)
    protected String employeeId;
    @XmlElement(name = "store_location", required = true)
    protected StatusListInquiryRequestMessageStoreLocationTypeBean storeLocation;
    @XmlElement(name = "request_ids", required = true)
    protected StatusListInquiryRequestMessageRequestIdsBean requestIds;
    protected StatusListInquiryRequestMessageStatusesBean statuses;
    @XmlAttribute(name = "response_type")
    protected String responseType;
    @XmlAttribute(name = "status_condition", required = true)
    protected String statusCondition;

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the employeeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the value of the employeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeId(String value) {
        this.employeeId = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryRequestMessageStoreLocationTypeBean }
     *     
     */
    public StatusListInquiryRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(StatusListInquiryRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the requestIds property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryRequestMessageRequestIdsBean }
     *     
     */
    public StatusListInquiryRequestMessageRequestIdsBean getRequestIds() {
        return requestIds;
    }

    /**
     * Sets the value of the requestIds property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryRequestMessageRequestIdsBean }
     *     
     */
    public void setRequestIds(StatusListInquiryRequestMessageRequestIdsBean value) {
        this.requestIds = value;
    }

    /**
     * Gets the value of the statuses property.
     * 
     * @return
     *     possible object is
     *     {@link StatusListInquiryRequestMessageStatusesBean }
     *     
     */
    public StatusListInquiryRequestMessageStatusesBean getStatuses() {
        return statuses;
    }

    /**
     * Sets the value of the statuses property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusListInquiryRequestMessageStatusesBean }
     *     
     */
    public void setStatuses(StatusListInquiryRequestMessageStatusesBean value) {
        this.statuses = value;
    }

    /**
     * Gets the value of the responseType property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getResponseType() {
        return responseType;
    }

    /**
     * Sets the value of the responseType property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setResponseType(String value) {
        this.responseType = value;
    }

    /**
     * Gets the value of the statusCondition property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusCondition() {
        return statusCondition;
    }

    /**
     * Sets the value of the statusCondition property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusCondition(String value) {
        this.statusCondition = value;
    }

}
