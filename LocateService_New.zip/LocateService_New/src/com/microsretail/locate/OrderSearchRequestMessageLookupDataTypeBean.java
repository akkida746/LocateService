
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for OrderSearchRequestMessageLookupDataTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="OrderSearchRequestMessageLookupDataTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ref_transaction_no" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *         &lt;element name="employee_id" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="max_no_responses" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}OrderSearchRequestMessageStoreLocationTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="order_id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="request_id" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_date" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_company" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_first_name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_last_name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_province" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_postal" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_country" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_phone" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="sold_to_email" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_company" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_first_name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_last_name" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_province" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_postal" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_country" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_phone" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="ship_to_email" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "OrderSearchRequestMessageLookupDataTypeBean", propOrder = {
    "refTransactionNo",
    "employeeId",
    "maxNoResponses",
    "storeLocation"
})
public class OrderSearchRequestMessageLookupDataTypeBean {

    @XmlElement(name = "ref_transaction_no")
    protected String refTransactionNo;
    @XmlElement(name = "employee_id", required = true)
    protected String employeeId;
    @XmlElement(name = "max_no_responses")
    protected Integer maxNoResponses;
    @XmlElement(name = "store_location", required = true)
    protected OrderSearchRequestMessageStoreLocationTypeBean storeLocation;
    @XmlAttribute(name = "order_id")
    protected String orderId;
    @XmlAttribute(name = "request_id")
    protected String requestId;
    @XmlAttribute(name = "order_date")
    protected String orderDate;
    @XmlAttribute(name = "sold_to_company")
    protected String soldToCompany;
    @XmlAttribute(name = "sold_to_first_name")
    protected String soldToFirstName;
    @XmlAttribute(name = "sold_to_last_name")
    protected String soldToLastName;
    @XmlAttribute(name = "sold_to_province")
    protected String soldToProvince;
    @XmlAttribute(name = "sold_to_postal")
    protected String soldToPostal;
    @XmlAttribute(name = "sold_to_country")
    protected String soldToCountry;
    @XmlAttribute(name = "sold_to_phone")
    protected String soldToPhone;
    @XmlAttribute(name = "sold_to_email")
    protected String soldToEmail;
    @XmlAttribute(name = "ship_to_company")
    protected String shipToCompany;
    @XmlAttribute(name = "ship_to_first_name")
    protected String shipToFirstName;
    @XmlAttribute(name = "ship_to_last_name")
    protected String shipToLastName;
    @XmlAttribute(name = "ship_to_province")
    protected String shipToProvince;
    @XmlAttribute(name = "ship_to_postal")
    protected String shipToPostal;
    @XmlAttribute(name = "ship_to_country")
    protected String shipToCountry;
    @XmlAttribute(name = "ship_to_phone")
    protected String shipToPhone;
    @XmlAttribute(name = "ship_to_email")
    protected String shipToEmail;

    /**
     * Gets the value of the refTransactionNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRefTransactionNo() {
        return refTransactionNo;
    }

    /**
     * Sets the value of the refTransactionNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRefTransactionNo(String value) {
        this.refTransactionNo = value;
    }

    /**
     * Gets the value of the employeeId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getEmployeeId() {
        return employeeId;
    }

    /**
     * Sets the value of the employeeId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmployeeId(String value) {
        this.employeeId = value;
    }

    /**
     * Gets the value of the maxNoResponses property.
     * 
     * @return
     *     possible object is
     *     {@link Integer }
     *     
     */
    public Integer getMaxNoResponses() {
        return maxNoResponses;
    }

    /**
     * Sets the value of the maxNoResponses property.
     * 
     * @param value
     *     allowed object is
     *     {@link Integer }
     *     
     */
    public void setMaxNoResponses(Integer value) {
        this.maxNoResponses = value;
    }

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link OrderSearchRequestMessageStoreLocationTypeBean }
     *     
     */
    public OrderSearchRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link OrderSearchRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(OrderSearchRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

    /**
     * Gets the value of the orderId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderId() {
        return orderId;
    }

    /**
     * Sets the value of the orderId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderId(String value) {
        this.orderId = value;
    }

    /**
     * Gets the value of the requestId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getRequestId() {
        return requestId;
    }

    /**
     * Sets the value of the requestId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setRequestId(String value) {
        this.requestId = value;
    }

    /**
     * Gets the value of the orderDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderDate() {
        return orderDate;
    }

    /**
     * Sets the value of the orderDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderDate(String value) {
        this.orderDate = value;
    }

    /**
     * Gets the value of the soldToCompany property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToCompany() {
        return soldToCompany;
    }

    /**
     * Sets the value of the soldToCompany property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToCompany(String value) {
        this.soldToCompany = value;
    }

    /**
     * Gets the value of the soldToFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToFirstName() {
        return soldToFirstName;
    }

    /**
     * Sets the value of the soldToFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToFirstName(String value) {
        this.soldToFirstName = value;
    }

    /**
     * Gets the value of the soldToLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToLastName() {
        return soldToLastName;
    }

    /**
     * Sets the value of the soldToLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToLastName(String value) {
        this.soldToLastName = value;
    }

    /**
     * Gets the value of the soldToProvince property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToProvince() {
        return soldToProvince;
    }

    /**
     * Sets the value of the soldToProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToProvince(String value) {
        this.soldToProvince = value;
    }

    /**
     * Gets the value of the soldToPostal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToPostal() {
        return soldToPostal;
    }

    /**
     * Sets the value of the soldToPostal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToPostal(String value) {
        this.soldToPostal = value;
    }

    /**
     * Gets the value of the soldToCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToCountry() {
        return soldToCountry;
    }

    /**
     * Sets the value of the soldToCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToCountry(String value) {
        this.soldToCountry = value;
    }

    /**
     * Gets the value of the soldToPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToPhone() {
        return soldToPhone;
    }

    /**
     * Sets the value of the soldToPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToPhone(String value) {
        this.soldToPhone = value;
    }

    /**
     * Gets the value of the soldToEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSoldToEmail() {
        return soldToEmail;
    }

    /**
     * Sets the value of the soldToEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSoldToEmail(String value) {
        this.soldToEmail = value;
    }

    /**
     * Gets the value of the shipToCompany property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToCompany() {
        return shipToCompany;
    }

    /**
     * Sets the value of the shipToCompany property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToCompany(String value) {
        this.shipToCompany = value;
    }

    /**
     * Gets the value of the shipToFirstName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToFirstName() {
        return shipToFirstName;
    }

    /**
     * Sets the value of the shipToFirstName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToFirstName(String value) {
        this.shipToFirstName = value;
    }

    /**
     * Gets the value of the shipToLastName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToLastName() {
        return shipToLastName;
    }

    /**
     * Sets the value of the shipToLastName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToLastName(String value) {
        this.shipToLastName = value;
    }

    /**
     * Gets the value of the shipToProvince property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToProvince() {
        return shipToProvince;
    }

    /**
     * Sets the value of the shipToProvince property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToProvince(String value) {
        this.shipToProvince = value;
    }

    /**
     * Gets the value of the shipToPostal property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToPostal() {
        return shipToPostal;
    }

    /**
     * Sets the value of the shipToPostal property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToPostal(String value) {
        this.shipToPostal = value;
    }

    /**
     * Gets the value of the shipToCountry property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToCountry() {
        return shipToCountry;
    }

    /**
     * Sets the value of the shipToCountry property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToCountry(String value) {
        this.shipToCountry = value;
    }

    /**
     * Gets the value of the shipToPhone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToPhone() {
        return shipToPhone;
    }

    /**
     * Sets the value of the shipToPhone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToPhone(String value) {
        this.shipToPhone = value;
    }

    /**
     * Gets the value of the shipToEmail property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShipToEmail() {
        return shipToEmail;
    }

    /**
     * Sets the value of the shipToEmail property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShipToEmail(String value) {
        this.shipToEmail = value;
    }

}
