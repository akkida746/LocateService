
package com.microsretail.locate;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="fulfillment_type" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean" maxOccurs="unbounded"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean", propOrder = {
    "fulfillmentType"
})
public class AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean {

    @XmlElement(name = "fulfillment_type", required = true)
    protected List<AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean> fulfillmentType;

    /**
     * Gets the value of the fulfillmentType property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the fulfillmentType property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getFulfillmentType().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean }
     * 
     * 
     */
    public List<AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean> getFulfillmentType() {
        if (fulfillmentType == null) {
            fulfillmentType = new ArrayList<AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean>();
        }
        return this.fulfillmentType;
    }

}
