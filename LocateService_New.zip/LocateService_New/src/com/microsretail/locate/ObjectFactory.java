
package com.microsretail.locate;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.microsretail.locate package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _EchoTest_QNAME = new QName("http://microsretail.com/Locate", "EchoTest");
    private final static QName _EchoTestResponse_QNAME = new QName("http://microsretail.com/Locate", "EchoTestResponse");
    private final static QName _Fulfillments_QNAME = new QName("http://microsretail.com/Locate", "Fulfillments");
    private final static QName _FulfillmentsResponse_QNAME = new QName("http://microsretail.com/Locate", "FulfillmentsResponse");
    private final static QName _LocateItems_QNAME = new QName("http://microsretail.com/Locate", "LocateItems");
    private final static QName _LocateItemsResponse_QNAME = new QName("http://microsretail.com/Locate", "LocateItemsResponse");
    private final static QName _OrderSearch_QNAME = new QName("http://microsretail.com/Locate", "OrderSearch");
    private final static QName _OrderSearchResponse_QNAME = new QName("http://microsretail.com/Locate", "OrderSearchResponse");
    private final static QName _OrderUpdate_QNAME = new QName("http://microsretail.com/Locate", "OrderUpdate");
    private final static QName _OrderUpdateResponse_QNAME = new QName("http://microsretail.com/Locate", "OrderUpdateResponse");
    private final static QName _ProductAvailability_QNAME = new QName("http://microsretail.com/Locate", "ProductAvailability");
    private final static QName _ProductAvailabilityResponse_QNAME = new QName("http://microsretail.com/Locate", "ProductAvailabilityResponse");
    private final static QName _ProductUpdate_QNAME = new QName("http://microsretail.com/Locate", "ProductUpdate");
    private final static QName _ProductUpdateResponse_QNAME = new QName("http://microsretail.com/Locate", "ProductUpdateResponse");
    private final static QName _StatusListRequest_QNAME = new QName("http://microsretail.com/Locate", "StatusListRequest");
    private final static QName _StatusListRequestResponse_QNAME = new QName("http://microsretail.com/Locate", "StatusListRequestResponse");
    private final static QName _StatusRequest_QNAME = new QName("http://microsretail.com/Locate", "StatusRequest");
    private final static QName _StatusRequestResponse_QNAME = new QName("http://microsretail.com/Locate", "StatusRequestResponse");
    private final static QName _StatusUpdate_QNAME = new QName("http://microsretail.com/Locate", "StatusUpdate");
    private final static QName _StatusUpdateResponse_QNAME = new QName("http://microsretail.com/Locate", "StatusUpdateResponse");
    private final static QName _SubmitOrder_QNAME = new QName("http://microsretail.com/Locate", "SubmitOrder");
    private final static QName _SubmitOrderResponse_QNAME = new QName("http://microsretail.com/Locate", "SubmitOrderResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.microsretail.locate
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link EchoTest }
     * 
     */
    public EchoTest createEchoTest() {
        return new EchoTest();
    }

    /**
     * Create an instance of {@link EchoTestResponse }
     * 
     */
    public EchoTestResponse createEchoTestResponse() {
        return new EchoTestResponse();
    }

    /**
     * Create an instance of {@link Fulfillments }
     * 
     */
    public Fulfillments createFulfillments() {
        return new Fulfillments();
    }

    /**
     * Create an instance of {@link FulfillmentsResponse }
     * 
     */
    public FulfillmentsResponse createFulfillmentsResponse() {
        return new FulfillmentsResponse();
    }

    /**
     * Create an instance of {@link LocateItems }
     * 
     */
    public LocateItems createLocateItems() {
        return new LocateItems();
    }

    /**
     * Create an instance of {@link LocateItemsResponse }
     * 
     */
    public LocateItemsResponse createLocateItemsResponse() {
        return new LocateItemsResponse();
    }

    /**
     * Create an instance of {@link OrderSearch }
     * 
     */
    public OrderSearch createOrderSearch() {
        return new OrderSearch();
    }

    /**
     * Create an instance of {@link OrderSearchResponse }
     * 
     */
    public OrderSearchResponse createOrderSearchResponse() {
        return new OrderSearchResponse();
    }

    /**
     * Create an instance of {@link OrderUpdate }
     * 
     */
    public OrderUpdate createOrderUpdate() {
        return new OrderUpdate();
    }

    /**
     * Create an instance of {@link OrderUpdateResponse }
     * 
     */
    public OrderUpdateResponse createOrderUpdateResponse() {
        return new OrderUpdateResponse();
    }

    /**
     * Create an instance of {@link ProductAvailability }
     * 
     */
    public ProductAvailability createProductAvailability() {
        return new ProductAvailability();
    }

    /**
     * Create an instance of {@link ProductAvailabilityResponse }
     * 
     */
    public ProductAvailabilityResponse createProductAvailabilityResponse() {
        return new ProductAvailabilityResponse();
    }

    /**
     * Create an instance of {@link ProductUpdate }
     * 
     */
    public ProductUpdate createProductUpdate() {
        return new ProductUpdate();
    }

    /**
     * Create an instance of {@link ProductUpdateResponse }
     * 
     */
    public ProductUpdateResponse createProductUpdateResponse() {
        return new ProductUpdateResponse();
    }

    /**
     * Create an instance of {@link StatusListRequest }
     * 
     */
    public StatusListRequest createStatusListRequest() {
        return new StatusListRequest();
    }

    /**
     * Create an instance of {@link StatusListRequestResponse }
     * 
     */
    public StatusListRequestResponse createStatusListRequestResponse() {
        return new StatusListRequestResponse();
    }

    /**
     * Create an instance of {@link StatusRequest }
     * 
     */
    public StatusRequest createStatusRequest() {
        return new StatusRequest();
    }

    /**
     * Create an instance of {@link StatusRequestResponse }
     * 
     */
    public StatusRequestResponse createStatusRequestResponse() {
        return new StatusRequestResponse();
    }

    /**
     * Create an instance of {@link StatusUpdate }
     * 
     */
    public StatusUpdate createStatusUpdate() {
        return new StatusUpdate();
    }

    /**
     * Create an instance of {@link StatusUpdateResponse }
     * 
     */
    public StatusUpdateResponse createStatusUpdateResponse() {
        return new StatusUpdateResponse();
    }

    /**
     * Create an instance of {@link SubmitOrder }
     * 
     */
    public SubmitOrder createSubmitOrder() {
        return new SubmitOrder();
    }

    /**
     * Create an instance of {@link SubmitOrderResponse }
     * 
     */
    public SubmitOrderResponse createSubmitOrderResponse() {
        return new SubmitOrderResponse();
    }

    /**
     * Create an instance of {@link StatusInquiryRequestMessageTypeBean }
     * 
     */
    public StatusInquiryRequestMessageTypeBean createStatusInquiryRequestMessageTypeBean() {
        return new StatusInquiryRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryRequestMessageHeaderTypeBean }
     * 
     */
    public StatusInquiryRequestMessageHeaderTypeBean createStatusInquiryRequestMessageHeaderTypeBean() {
        return new StatusInquiryRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryRequestMessageBodyTypeBean }
     * 
     */
    public StatusInquiryRequestMessageBodyTypeBean createStatusInquiryRequestMessageBodyTypeBean() {
        return new StatusInquiryRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryRequestMessageLookupDataTypeBean }
     * 
     */
    public StatusInquiryRequestMessageLookupDataTypeBean createStatusInquiryRequestMessageLookupDataTypeBean() {
        return new StatusInquiryRequestMessageLookupDataTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryRequestMessageStoreLocationTypeBean }
     * 
     */
    public StatusInquiryRequestMessageStoreLocationTypeBean createStatusInquiryRequestMessageStoreLocationTypeBean() {
        return new StatusInquiryRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link StatusResponseMessageTypeBean }
     * 
     */
    public StatusResponseMessageTypeBean createStatusResponseMessageTypeBean() {
        return new StatusResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link MessageHeaderTypeBean }
     * 
     */
    public MessageHeaderTypeBean createMessageHeaderTypeBean() {
        return new MessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryResponseMessageBodyTypeBean }
     * 
     */
    public StatusInquiryResponseMessageBodyTypeBean createStatusInquiryResponseMessageBodyTypeBean() {
        return new StatusInquiryResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryResponseMessageOrdersTypeBean }
     * 
     */
    public StatusInquiryResponseMessageOrdersTypeBean createStatusInquiryResponseMessageOrdersTypeBean() {
        return new StatusInquiryResponseMessageOrdersTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryResponseMessageOrderTypeBean }
     * 
     */
    public StatusInquiryResponseMessageOrderTypeBean createStatusInquiryResponseMessageOrderTypeBean() {
        return new StatusInquiryResponseMessageOrderTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryResponseMessageItemsTypeBean }
     * 
     */
    public StatusInquiryResponseMessageItemsTypeBean createStatusInquiryResponseMessageItemsTypeBean() {
        return new StatusInquiryResponseMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link StatusInquiryResponseMessageItemTypeBean }
     * 
     */
    public StatusInquiryResponseMessageItemTypeBean createStatusInquiryResponseMessageItemTypeBean() {
        return new StatusInquiryResponseMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link CustomerTypeBean }
     * 
     */
    public CustomerTypeBean createCustomerTypeBean() {
        return new CustomerTypeBean();
    }

    /**
     * Create an instance of {@link NameTypeBean }
     * 
     */
    public NameTypeBean createNameTypeBean() {
        return new NameTypeBean();
    }

    /**
     * Create an instance of {@link AddressTypeBean }
     * 
     */
    public AddressTypeBean createAddressTypeBean() {
        return new AddressTypeBean();
    }

    /**
     * Create an instance of {@link TaxesTypeBean }
     * 
     */
    public TaxesTypeBean createTaxesTypeBean() {
        return new TaxesTypeBean();
    }

    /**
     * Create an instance of {@link TaxTypeBean }
     * 
     */
    public TaxTypeBean createTaxTypeBean() {
        return new TaxTypeBean();
    }

    /**
     * Create an instance of {@link DSSalesOrderCustomizationsTypeBean }
     * 
     */
    public DSSalesOrderCustomizationsTypeBean createDSSalesOrderCustomizationsTypeBean() {
        return new DSSalesOrderCustomizationsTypeBean();
    }

    /**
     * Create an instance of {@link DSSalesOrderCustomizationTypeBean }
     * 
     */
    public DSSalesOrderCustomizationTypeBean createDSSalesOrderCustomizationTypeBean() {
        return new DSSalesOrderCustomizationTypeBean();
    }

    /**
     * Create an instance of {@link SoldToCustomerTypeBean }
     * 
     */
    public SoldToCustomerTypeBean createSoldToCustomerTypeBean() {
        return new SoldToCustomerTypeBean();
    }

    /**
     * Create an instance of {@link TransactionTendersTypeBean }
     * 
     */
    public TransactionTendersTypeBean createTransactionTendersTypeBean() {
        return new TransactionTendersTypeBean();
    }

    /**
     * Create an instance of {@link TransactionTenderTypeBean }
     * 
     */
    public TransactionTenderTypeBean createTransactionTenderTypeBean() {
        return new TransactionTenderTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageTypeBean }
     * 
     */
    public ProductUpdateRequestMessageTypeBean createProductUpdateRequestMessageTypeBean() {
        return new ProductUpdateRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageHeaderTypeBean }
     * 
     */
    public ProductUpdateRequestMessageHeaderTypeBean createProductUpdateRequestMessageHeaderTypeBean() {
        return new ProductUpdateRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageBodyTypeBean }
     * 
     */
    public ProductUpdateRequestMessageBodyTypeBean createProductUpdateRequestMessageBodyTypeBean() {
        return new ProductUpdateRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageSystemProductTypeBean }
     * 
     */
    public ProductUpdateRequestMessageSystemProductTypeBean createProductUpdateRequestMessageSystemProductTypeBean() {
        return new ProductUpdateRequestMessageSystemProductTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageProductLocationsTypeBean }
     * 
     */
    public ProductUpdateRequestMessageProductLocationsTypeBean createProductUpdateRequestMessageProductLocationsTypeBean() {
        return new ProductUpdateRequestMessageProductLocationsTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateRequestMessageProductLocationTypeBean }
     * 
     */
    public ProductUpdateRequestMessageProductLocationTypeBean createProductUpdateRequestMessageProductLocationTypeBean() {
        return new ProductUpdateRequestMessageProductLocationTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateResponseMessageTypeBean }
     * 
     */
    public ProductUpdateResponseMessageTypeBean createProductUpdateResponseMessageTypeBean() {
        return new ProductUpdateResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateResponseMessageHeaderTypeBean }
     * 
     */
    public ProductUpdateResponseMessageHeaderTypeBean createProductUpdateResponseMessageHeaderTypeBean() {
        return new ProductUpdateResponseMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link ProductUpdateResponseMessageBodyTypeBean }
     * 
     */
    public ProductUpdateResponseMessageBodyTypeBean createProductUpdateResponseMessageBodyTypeBean() {
        return new ProductUpdateResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateRequestMessageTypeBean }
     * 
     */
    public OrderUpdateRequestMessageTypeBean createOrderUpdateRequestMessageTypeBean() {
        return new OrderUpdateRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateRequestMessageHeaderTypeBean }
     * 
     */
    public OrderUpdateRequestMessageHeaderTypeBean createOrderUpdateRequestMessageHeaderTypeBean() {
        return new OrderUpdateRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateRequestMessageBodyTypeBean }
     * 
     */
    public OrderUpdateRequestMessageBodyTypeBean createOrderUpdateRequestMessageBodyTypeBean() {
        return new OrderUpdateRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateRequestMessageOrderTypeBean }
     * 
     */
    public OrderUpdateRequestMessageOrderTypeBean createOrderUpdateRequestMessageOrderTypeBean() {
        return new OrderUpdateRequestMessageOrderTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateRequestMessageStoreLocationTypeBean }
     * 
     */
    public OrderUpdateRequestMessageStoreLocationTypeBean createOrderUpdateRequestMessageStoreLocationTypeBean() {
        return new OrderUpdateRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateResponseMessageTypeBean }
     * 
     */
    public OrderUpdateResponseMessageTypeBean createOrderUpdateResponseMessageTypeBean() {
        return new OrderUpdateResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateResponseMessageBodyTypeBean }
     * 
     */
    public OrderUpdateResponseMessageBodyTypeBean createOrderUpdateResponseMessageBodyTypeBean() {
        return new OrderUpdateResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link OrderUpdateResponseMessageResponseTypeBean }
     * 
     */
    public OrderUpdateResponseMessageResponseTypeBean createOrderUpdateResponseMessageResponseTypeBean() {
        return new OrderUpdateResponseMessageResponseTypeBean();
    }

    /**
     * Create an instance of {@link OrderSearchRequestMessageTypeBean }
     * 
     */
    public OrderSearchRequestMessageTypeBean createOrderSearchRequestMessageTypeBean() {
        return new OrderSearchRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link OrderSearchMessageHeaderTypeBean }
     * 
     */
    public OrderSearchMessageHeaderTypeBean createOrderSearchMessageHeaderTypeBean() {
        return new OrderSearchMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link OrderSearchRequestMessageBodyTypeBean }
     * 
     */
    public OrderSearchRequestMessageBodyTypeBean createOrderSearchRequestMessageBodyTypeBean() {
        return new OrderSearchRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link OrderSearchRequestMessageLookupDataTypeBean }
     * 
     */
    public OrderSearchRequestMessageLookupDataTypeBean createOrderSearchRequestMessageLookupDataTypeBean() {
        return new OrderSearchRequestMessageLookupDataTypeBean();
    }

    /**
     * Create an instance of {@link OrderSearchRequestMessageStoreLocationTypeBean }
     * 
     */
    public OrderSearchRequestMessageStoreLocationTypeBean createOrderSearchRequestMessageStoreLocationTypeBean() {
        return new OrderSearchRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageTypeBean }
     * 
     */
    public StatusUpdateRequestMessageTypeBean createStatusUpdateRequestMessageTypeBean() {
        return new StatusUpdateRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageHeaderTypeBean }
     * 
     */
    public StatusUpdateRequestMessageHeaderTypeBean createStatusUpdateRequestMessageHeaderTypeBean() {
        return new StatusUpdateRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageBodyTypeBean }
     * 
     */
    public StatusUpdateRequestMessageBodyTypeBean createStatusUpdateRequestMessageBodyTypeBean() {
        return new StatusUpdateRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageOrderTypeBean }
     * 
     */
    public StatusUpdateRequestMessageOrderTypeBean createStatusUpdateRequestMessageOrderTypeBean() {
        return new StatusUpdateRequestMessageOrderTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageStoreLocationTypeBean }
     * 
     */
    public StatusUpdateRequestMessageStoreLocationTypeBean createStatusUpdateRequestMessageStoreLocationTypeBean() {
        return new StatusUpdateRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageItemsTypeBean }
     * 
     */
    public StatusUpdateRequestMessageItemsTypeBean createStatusUpdateRequestMessageItemsTypeBean() {
        return new StatusUpdateRequestMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateRequestMessageItemTypeBean }
     * 
     */
    public StatusUpdateRequestMessageItemTypeBean createStatusUpdateRequestMessageItemTypeBean() {
        return new StatusUpdateRequestMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateResponseMessageTypeBean }
     * 
     */
    public StatusUpdateResponseMessageTypeBean createStatusUpdateResponseMessageTypeBean() {
        return new StatusUpdateResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateResponseMessageBodyTypeBean }
     * 
     */
    public StatusUpdateResponseMessageBodyTypeBean createStatusUpdateResponseMessageBodyTypeBean() {
        return new StatusUpdateResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusUpdateResponseMessageResponseTypeBean }
     * 
     */
    public StatusUpdateResponseMessageResponseTypeBean createStatusUpdateResponseMessageResponseTypeBean() {
        return new StatusUpdateResponseMessageResponseTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentRequestMessageTypeBean }
     * 
     */
    public FulfillmentRequestMessageTypeBean createFulfillmentRequestMessageTypeBean() {
        return new FulfillmentRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentRequestMessageHeaderTypeBean }
     * 
     */
    public FulfillmentRequestMessageHeaderTypeBean createFulfillmentRequestMessageHeaderTypeBean() {
        return new FulfillmentRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentRequestMessageBodyTypeBean }
     * 
     */
    public FulfillmentRequestMessageBodyTypeBean createFulfillmentRequestMessageBodyTypeBean() {
        return new FulfillmentRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentRequestMessageStoreLocationTypeBean }
     * 
     */
    public FulfillmentRequestMessageStoreLocationTypeBean createFulfillmentRequestMessageStoreLocationTypeBean() {
        return new FulfillmentRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageTypeBean }
     * 
     */
    public FulfillmentResponseMessageTypeBean createFulfillmentResponseMessageTypeBean() {
        return new FulfillmentResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageBodyTypeBean }
     * 
     */
    public FulfillmentResponseMessageBodyTypeBean createFulfillmentResponseMessageBodyTypeBean() {
        return new FulfillmentResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageOrdersTypeBean }
     * 
     */
    public FulfillmentResponseMessageOrdersTypeBean createFulfillmentResponseMessageOrdersTypeBean() {
        return new FulfillmentResponseMessageOrdersTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageOrderTypeBean }
     * 
     */
    public FulfillmentResponseMessageOrderTypeBean createFulfillmentResponseMessageOrderTypeBean() {
        return new FulfillmentResponseMessageOrderTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageStoreLocationTypeBean }
     * 
     */
    public FulfillmentResponseMessageStoreLocationTypeBean createFulfillmentResponseMessageStoreLocationTypeBean() {
        return new FulfillmentResponseMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageItemsTypeBean }
     * 
     */
    public FulfillmentResponseMessageItemsTypeBean createFulfillmentResponseMessageItemsTypeBean() {
        return new FulfillmentResponseMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link FulfillmentResponseMessageItemTypeBean }
     * 
     */
    public FulfillmentResponseMessageItemTypeBean createFulfillmentResponseMessageItemTypeBean() {
        return new FulfillmentResponseMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageTypeBean }
     * 
     */
    public StatusListInquiryRequestMessageTypeBean createStatusListInquiryRequestMessageTypeBean() {
        return new StatusListInquiryRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageHeaderTypeBean }
     * 
     */
    public StatusListInquiryRequestMessageHeaderTypeBean createStatusListInquiryRequestMessageHeaderTypeBean() {
        return new StatusListInquiryRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageBodyTypeBean }
     * 
     */
    public StatusListInquiryRequestMessageBodyTypeBean createStatusListInquiryRequestMessageBodyTypeBean() {
        return new StatusListInquiryRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageLookupDataTypeBean }
     * 
     */
    public StatusListInquiryRequestMessageLookupDataTypeBean createStatusListInquiryRequestMessageLookupDataTypeBean() {
        return new StatusListInquiryRequestMessageLookupDataTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageStoreLocationTypeBean }
     * 
     */
    public StatusListInquiryRequestMessageStoreLocationTypeBean createStatusListInquiryRequestMessageStoreLocationTypeBean() {
        return new StatusListInquiryRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageRequestIdsBean }
     * 
     */
    public StatusListInquiryRequestMessageRequestIdsBean createStatusListInquiryRequestMessageRequestIdsBean() {
        return new StatusListInquiryRequestMessageRequestIdsBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageRequestIdBean }
     * 
     */
    public StatusListInquiryRequestMessageRequestIdBean createStatusListInquiryRequestMessageRequestIdBean() {
        return new StatusListInquiryRequestMessageRequestIdBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageStatusesBean }
     * 
     */
    public StatusListInquiryRequestMessageStatusesBean createStatusListInquiryRequestMessageStatusesBean() {
        return new StatusListInquiryRequestMessageStatusesBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryRequestMessageStatusBean }
     * 
     */
    public StatusListInquiryRequestMessageStatusBean createStatusListInquiryRequestMessageStatusBean() {
        return new StatusListInquiryRequestMessageStatusBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageTypeBean createStatusListInquiryResponseMessageTypeBean() {
        return new StatusListInquiryResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageBodyTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageBodyTypeBean createStatusListInquiryResponseMessageBodyTypeBean() {
        return new StatusListInquiryResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageOrdersTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageOrdersTypeBean createStatusListInquiryResponseMessageOrdersTypeBean() {
        return new StatusListInquiryResponseMessageOrdersTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageOrderTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageOrderTypeBean createStatusListInquiryResponseMessageOrderTypeBean() {
        return new StatusListInquiryResponseMessageOrderTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageItemsTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageItemsTypeBean createStatusListInquiryResponseMessageItemsTypeBean() {
        return new StatusListInquiryResponseMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link StatusListInquiryResponseMessageItemTypeBean }
     * 
     */
    public StatusListInquiryResponseMessageItemTypeBean createStatusListInquiryResponseMessageItemTypeBean() {
        return new StatusListInquiryResponseMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestMessageTypeBean }
     * 
     */
    public SubmitOrderRequestMessageTypeBean createSubmitOrderRequestMessageTypeBean() {
        return new SubmitOrderRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestMessageHeaderTypeBean }
     * 
     */
    public SubmitOrderRequestMessageHeaderTypeBean createSubmitOrderRequestMessageHeaderTypeBean() {
        return new SubmitOrderRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestMessageBodyTypeBean }
     * 
     */
    public SubmitOrderRequestMessageBodyTypeBean createSubmitOrderRequestMessageBodyTypeBean() {
        return new SubmitOrderRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestMessageTransactionsTypeBean }
     * 
     */
    public SubmitOrderRequestMessageTransactionsTypeBean createSubmitOrderRequestMessageTransactionsTypeBean() {
        return new SubmitOrderRequestMessageTransactionsTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestMessageTransactionHeaderTypeBean }
     * 
     */
    public SubmitOrderRequestMessageTransactionHeaderTypeBean createSubmitOrderRequestMessageTransactionHeaderTypeBean() {
        return new SubmitOrderRequestMessageTransactionHeaderTypeBean();
    }

    /**
     * Create an instance of {@link StoreLocationTypeBean }
     * 
     */
    public StoreLocationTypeBean createStoreLocationTypeBean() {
        return new StoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestTransactionDetailsTypeBean }
     * 
     */
    public SubmitOrderRequestTransactionDetailsTypeBean createSubmitOrderRequestTransactionDetailsTypeBean() {
        return new SubmitOrderRequestTransactionDetailsTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderRequestTransactionDetailTypeBean }
     * 
     */
    public SubmitOrderRequestTransactionDetailTypeBean createSubmitOrderRequestTransactionDetailTypeBean() {
        return new SubmitOrderRequestTransactionDetailTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderResponseMessageTypeBean }
     * 
     */
    public SubmitOrderResponseMessageTypeBean createSubmitOrderResponseMessageTypeBean() {
        return new SubmitOrderResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderResponseMessageBodyTypeBean }
     * 
     */
    public SubmitOrderResponseMessageBodyTypeBean createSubmitOrderResponseMessageBodyTypeBean() {
        return new SubmitOrderResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderResponseMessageResponseTypeBean }
     * 
     */
    public SubmitOrderResponseMessageResponseTypeBean createSubmitOrderResponseMessageResponseTypeBean() {
        return new SubmitOrderResponseMessageResponseTypeBean();
    }

    /**
     * Create an instance of {@link SubmitOrderResponseMessageFulfillmentDetails }
     * 
     */
    public SubmitOrderResponseMessageFulfillmentDetails createSubmitOrderResponseMessageFulfillmentDetails() {
        return new SubmitOrderResponseMessageFulfillmentDetails();
    }

    /**
     * Create an instance of {@link SubmitOrderResponseMessageFulfillmentDetail }
     * 
     */
    public SubmitOrderResponseMessageFulfillmentDetail createSubmitOrderResponseMessageFulfillmentDetail() {
        return new SubmitOrderResponseMessageFulfillmentDetail();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageTypeBean createAvailabilityByOrderTypeRequestMessageTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageHeaderTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageHeaderTypeBean createAvailabilityByOrderTypeRequestMessageHeaderTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageBodyTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageBodyTypeBean createAvailabilityByOrderTypeRequestMessageBodyTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean createAvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageFulfillmentsTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean createAvailabilityByOrderTypeRequestMessageFulfillmentTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageFulfillmentTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageItemsTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageItemsTypeBean createAvailabilityByOrderTypeRequestMessageItemsTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageItemTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageItemTypeBean createAvailabilityByOrderTypeRequestMessageItemTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeRequestMessageAddressTypeBean }
     * 
     */
    public AvailabilityByOrderTypeRequestMessageAddressTypeBean createAvailabilityByOrderTypeRequestMessageAddressTypeBean() {
        return new AvailabilityByOrderTypeRequestMessageAddressTypeBean();
    }

    /**
     * Create an instance of {@link ProductAvailabilityResponseMessageTypeBean }
     * 
     */
    public ProductAvailabilityResponseMessageTypeBean createProductAvailabilityResponseMessageTypeBean() {
        return new ProductAvailabilityResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderResponseMessageBodyTypeBean }
     * 
     */
    public AvailabilityByOrderResponseMessageBodyTypeBean createAvailabilityByOrderResponseMessageBodyTypeBean() {
        return new AvailabilityByOrderResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageFulfillmentsTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageFulfillmentsTypeBean createAvailabilityByOrderTypeResponseMessageFulfillmentsTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageFulfillmentsTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean createAvailabilityByOrderTypeResponseMessageFulfillmentTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageFulfillmentTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageItemsTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageItemsTypeBean createAvailabilityByOrderTypeResponseMessageItemsTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageItemTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageItemTypeBean createAvailabilityByOrderTypeResponseMessageItemTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageLocationLookupTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageLocationLookupTypeBean createAvailabilityByOrderTypeResponseMessageLocationLookupTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageLocationLookupTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageLocationsTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageLocationsTypeBean createAvailabilityByOrderTypeResponseMessageLocationsTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageLocationsTypeBean();
    }

    /**
     * Create an instance of {@link AvailabilityByOrderTypeResponseMessageLocationTypeBean }
     * 
     */
    public AvailabilityByOrderTypeResponseMessageLocationTypeBean createAvailabilityByOrderTypeResponseMessageLocationTypeBean() {
        return new AvailabilityByOrderTypeResponseMessageLocationTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageTypeBean }
     * 
     */
    public LocateItemsRequestMessageTypeBean createLocateItemsRequestMessageTypeBean() {
        return new LocateItemsRequestMessageTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageHeaderTypeBean }
     * 
     */
    public LocateItemsRequestMessageHeaderTypeBean createLocateItemsRequestMessageHeaderTypeBean() {
        return new LocateItemsRequestMessageHeaderTypeBean();
    }

    /**
     * Create an instance of {@link LocateIemsRequestMessageBodyTypeBean }
     * 
     */
    public LocateIemsRequestMessageBodyTypeBean createLocateIemsRequestMessageBodyTypeBean() {
        return new LocateIemsRequestMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageItemsTypeBean }
     * 
     */
    public LocateItemsRequestMessageItemsTypeBean createLocateItemsRequestMessageItemsTypeBean() {
        return new LocateItemsRequestMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageItemTypeBean }
     * 
     */
    public LocateItemsRequestMessageItemTypeBean createLocateItemsRequestMessageItemTypeBean() {
        return new LocateItemsRequestMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageStoreLocationTypeBean }
     * 
     */
    public LocateItemsRequestMessageStoreLocationTypeBean createLocateItemsRequestMessageStoreLocationTypeBean() {
        return new LocateItemsRequestMessageStoreLocationTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageAddressTypeBean }
     * 
     */
    public LocateItemsRequestMessageAddressTypeBean createLocateItemsRequestMessageAddressTypeBean() {
        return new LocateItemsRequestMessageAddressTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageRangeTypeBean }
     * 
     */
    public LocateItemsRequestMessageRangeTypeBean createLocateItemsRequestMessageRangeTypeBean() {
        return new LocateItemsRequestMessageRangeTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsRequestMessageRequestedLocationTypeBean }
     * 
     */
    public LocateItemsRequestMessageRequestedLocationTypeBean createLocateItemsRequestMessageRequestedLocationTypeBean() {
        return new LocateItemsRequestMessageRequestedLocationTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageTypeBean }
     * 
     */
    public LocateItemsResponseMessageTypeBean createLocateItemsResponseMessageTypeBean() {
        return new LocateItemsResponseMessageTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageBodyTypeBean }
     * 
     */
    public LocateItemsResponseMessageBodyTypeBean createLocateItemsResponseMessageBodyTypeBean() {
        return new LocateItemsResponseMessageBodyTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageItemsTypeBean }
     * 
     */
    public LocateItemsResponseMessageItemsTypeBean createLocateItemsResponseMessageItemsTypeBean() {
        return new LocateItemsResponseMessageItemsTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageItemTypeBean }
     * 
     */
    public LocateItemsResponseMessageItemTypeBean createLocateItemsResponseMessageItemTypeBean() {
        return new LocateItemsResponseMessageItemTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageLocationLookupTypeBean }
     * 
     */
    public LocateItemsResponseMessageLocationLookupTypeBean createLocateItemsResponseMessageLocationLookupTypeBean() {
        return new LocateItemsResponseMessageLocationLookupTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageLocationsTypeBean }
     * 
     */
    public LocateItemsResponseMessageLocationsTypeBean createLocateItemsResponseMessageLocationsTypeBean() {
        return new LocateItemsResponseMessageLocationsTypeBean();
    }

    /**
     * Create an instance of {@link LocateItemsResponseMessageLocationTypeBean }
     * 
     */
    public LocateItemsResponseMessageLocationTypeBean createLocateItemsResponseMessageLocationTypeBean() {
        return new LocateItemsResponseMessageLocationTypeBean();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EchoTest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "EchoTest")
    public JAXBElement<EchoTest> createEchoTest(EchoTest value) {
        return new JAXBElement<EchoTest>(_EchoTest_QNAME, EchoTest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link EchoTestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "EchoTestResponse")
    public JAXBElement<EchoTestResponse> createEchoTestResponse(EchoTestResponse value) {
        return new JAXBElement<EchoTestResponse>(_EchoTestResponse_QNAME, EchoTestResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Fulfillments }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "Fulfillments")
    public JAXBElement<Fulfillments> createFulfillments(Fulfillments value) {
        return new JAXBElement<Fulfillments>(_Fulfillments_QNAME, Fulfillments.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link FulfillmentsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "FulfillmentsResponse")
    public JAXBElement<FulfillmentsResponse> createFulfillmentsResponse(FulfillmentsResponse value) {
        return new JAXBElement<FulfillmentsResponse>(_FulfillmentsResponse_QNAME, FulfillmentsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocateItems }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "LocateItems")
    public JAXBElement<LocateItems> createLocateItems(LocateItems value) {
        return new JAXBElement<LocateItems>(_LocateItems_QNAME, LocateItems.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LocateItemsResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "LocateItemsResponse")
    public JAXBElement<LocateItemsResponse> createLocateItemsResponse(LocateItemsResponse value) {
        return new JAXBElement<LocateItemsResponse>(_LocateItemsResponse_QNAME, LocateItemsResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderSearch }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "OrderSearch")
    public JAXBElement<OrderSearch> createOrderSearch(OrderSearch value) {
        return new JAXBElement<OrderSearch>(_OrderSearch_QNAME, OrderSearch.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderSearchResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "OrderSearchResponse")
    public JAXBElement<OrderSearchResponse> createOrderSearchResponse(OrderSearchResponse value) {
        return new JAXBElement<OrderSearchResponse>(_OrderSearchResponse_QNAME, OrderSearchResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderUpdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "OrderUpdate")
    public JAXBElement<OrderUpdate> createOrderUpdate(OrderUpdate value) {
        return new JAXBElement<OrderUpdate>(_OrderUpdate_QNAME, OrderUpdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link OrderUpdateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "OrderUpdateResponse")
    public JAXBElement<OrderUpdateResponse> createOrderUpdateResponse(OrderUpdateResponse value) {
        return new JAXBElement<OrderUpdateResponse>(_OrderUpdateResponse_QNAME, OrderUpdateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductAvailability }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "ProductAvailability")
    public JAXBElement<ProductAvailability> createProductAvailability(ProductAvailability value) {
        return new JAXBElement<ProductAvailability>(_ProductAvailability_QNAME, ProductAvailability.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductAvailabilityResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "ProductAvailabilityResponse")
    public JAXBElement<ProductAvailabilityResponse> createProductAvailabilityResponse(ProductAvailabilityResponse value) {
        return new JAXBElement<ProductAvailabilityResponse>(_ProductAvailabilityResponse_QNAME, ProductAvailabilityResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductUpdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "ProductUpdate")
    public JAXBElement<ProductUpdate> createProductUpdate(ProductUpdate value) {
        return new JAXBElement<ProductUpdate>(_ProductUpdate_QNAME, ProductUpdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ProductUpdateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "ProductUpdateResponse")
    public JAXBElement<ProductUpdateResponse> createProductUpdateResponse(ProductUpdateResponse value) {
        return new JAXBElement<ProductUpdateResponse>(_ProductUpdateResponse_QNAME, ProductUpdateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusListRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusListRequest")
    public JAXBElement<StatusListRequest> createStatusListRequest(StatusListRequest value) {
        return new JAXBElement<StatusListRequest>(_StatusListRequest_QNAME, StatusListRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusListRequestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusListRequestResponse")
    public JAXBElement<StatusListRequestResponse> createStatusListRequestResponse(StatusListRequestResponse value) {
        return new JAXBElement<StatusListRequestResponse>(_StatusListRequestResponse_QNAME, StatusListRequestResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusRequest }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusRequest")
    public JAXBElement<StatusRequest> createStatusRequest(StatusRequest value) {
        return new JAXBElement<StatusRequest>(_StatusRequest_QNAME, StatusRequest.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusRequestResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusRequestResponse")
    public JAXBElement<StatusRequestResponse> createStatusRequestResponse(StatusRequestResponse value) {
        return new JAXBElement<StatusRequestResponse>(_StatusRequestResponse_QNAME, StatusRequestResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusUpdate }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusUpdate")
    public JAXBElement<StatusUpdate> createStatusUpdate(StatusUpdate value) {
        return new JAXBElement<StatusUpdate>(_StatusUpdate_QNAME, StatusUpdate.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link StatusUpdateResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "StatusUpdateResponse")
    public JAXBElement<StatusUpdateResponse> createStatusUpdateResponse(StatusUpdateResponse value) {
        return new JAXBElement<StatusUpdateResponse>(_StatusUpdateResponse_QNAME, StatusUpdateResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitOrder }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "SubmitOrder")
    public JAXBElement<SubmitOrder> createSubmitOrder(SubmitOrder value) {
        return new JAXBElement<SubmitOrder>(_SubmitOrder_QNAME, SubmitOrder.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SubmitOrderResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://microsretail.com/Locate", name = "SubmitOrderResponse")
    public JAXBElement<SubmitOrderResponse> createSubmitOrderResponse(SubmitOrderResponse value) {
        return new JAXBElement<SubmitOrderResponse>(_SubmitOrderResponse_QNAME, SubmitOrderResponse.class, null, value);
    }

}
