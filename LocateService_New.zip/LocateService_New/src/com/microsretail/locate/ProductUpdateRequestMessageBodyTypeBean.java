
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdateRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdateRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="system_product" type="{http://microsretail.com/Locate}ProductUpdateRequestMessageSystemProductTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdateRequestMessageBodyTypeBean", propOrder = {
    "systemProduct"
})
public class ProductUpdateRequestMessageBodyTypeBean {

    @XmlElement(name = "system_product", required = true)
    protected ProductUpdateRequestMessageSystemProductTypeBean systemProduct;

    /**
     * Gets the value of the systemProduct property.
     * 
     * @return
     *     possible object is
     *     {@link ProductUpdateRequestMessageSystemProductTypeBean }
     *     
     */
    public ProductUpdateRequestMessageSystemProductTypeBean getSystemProduct() {
        return systemProduct;
    }

    /**
     * Sets the value of the systemProduct property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductUpdateRequestMessageSystemProductTypeBean }
     *     
     */
    public void setSystemProduct(ProductUpdateRequestMessageSystemProductTypeBean value) {
        this.systemProduct = value;
    }

}
