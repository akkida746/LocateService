
package com.microsretail.locate;

import java.math.BigDecimal;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusListInquiryResponseMessageItemTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusListInquiryResponseMessageItemTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="customizations" type="{http://microsretail.com/Locate}DSSalesOrderCustomizationsTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *       &lt;attribute name="item_id" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_qty" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="shipping_agent" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="tracking_number" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_status" use="required" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fulfilling_location_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="fulfilling_system_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="requesting_system_line_no" use="required" type="{http://www.w3.org/2001/XMLSchema}int" /&gt;
 *       &lt;attribute name="status_date" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_upc_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="item_ean_cd" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_line_extended_freight" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_line_customization_charge" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_line_gift_wrap" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_line_ship_alone" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *       &lt;attribute name="order_line_ship_weight" type="{http://www.w3.org/2001/XMLSchema}decimal" /&gt;
 *       &lt;attribute name="order_line_message" type="{http://www.w3.org/2001/XMLSchema}string" /&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusListInquiryResponseMessageItemTypeBean", propOrder = {
    "customizations"
})
public class StatusListInquiryResponseMessageItemTypeBean {

    protected DSSalesOrderCustomizationsTypeBean customizations;
    @XmlAttribute(name = "item_id", required = true)
    protected String itemId;
    @XmlAttribute(name = "item_qty", required = true)
    protected int itemQty;
    @XmlAttribute(name = "shipping_agent", required = true)
    protected String shippingAgent;
    @XmlAttribute(name = "tracking_number", required = true)
    protected String trackingNumber;
    @XmlAttribute(name = "item_status", required = true)
    protected String itemStatus;
    @XmlAttribute(name = "fulfilling_location_cd")
    protected String fulfillingLocationCd;
    @XmlAttribute(name = "fulfilling_system_cd")
    protected String fulfillingSystemCd;
    @XmlAttribute(name = "line_no", required = true)
    protected int lineNo;
    @XmlAttribute(name = "requesting_system_line_no", required = true)
    protected int requestingSystemLineNo;
    @XmlAttribute(name = "status_date")
    protected String statusDate;
    @XmlAttribute(name = "item_upc_cd")
    protected String itemUpcCd;
    @XmlAttribute(name = "item_ean_cd")
    protected String itemEanCd;
    @XmlAttribute(name = "order_line_extended_freight")
    protected BigDecimal orderLineExtendedFreight;
    @XmlAttribute(name = "order_line_customization_charge")
    protected BigDecimal orderLineCustomizationCharge;
    @XmlAttribute(name = "order_line_gift_wrap")
    protected String orderLineGiftWrap;
    @XmlAttribute(name = "order_line_ship_alone")
    protected String orderLineShipAlone;
    @XmlAttribute(name = "order_line_ship_weight")
    protected BigDecimal orderLineShipWeight;
    @XmlAttribute(name = "order_line_message")
    protected String orderLineMessage;

    /**
     * Gets the value of the customizations property.
     * 
     * @return
     *     possible object is
     *     {@link DSSalesOrderCustomizationsTypeBean }
     *     
     */
    public DSSalesOrderCustomizationsTypeBean getCustomizations() {
        return customizations;
    }

    /**
     * Sets the value of the customizations property.
     * 
     * @param value
     *     allowed object is
     *     {@link DSSalesOrderCustomizationsTypeBean }
     *     
     */
    public void setCustomizations(DSSalesOrderCustomizationsTypeBean value) {
        this.customizations = value;
    }

    /**
     * Gets the value of the itemId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemId() {
        return itemId;
    }

    /**
     * Sets the value of the itemId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemId(String value) {
        this.itemId = value;
    }

    /**
     * Gets the value of the itemQty property.
     * 
     */
    public int getItemQty() {
        return itemQty;
    }

    /**
     * Sets the value of the itemQty property.
     * 
     */
    public void setItemQty(int value) {
        this.itemQty = value;
    }

    /**
     * Gets the value of the shippingAgent property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getShippingAgent() {
        return shippingAgent;
    }

    /**
     * Sets the value of the shippingAgent property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setShippingAgent(String value) {
        this.shippingAgent = value;
    }

    /**
     * Gets the value of the trackingNumber property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTrackingNumber() {
        return trackingNumber;
    }

    /**
     * Sets the value of the trackingNumber property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTrackingNumber(String value) {
        this.trackingNumber = value;
    }

    /**
     * Gets the value of the itemStatus property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemStatus() {
        return itemStatus;
    }

    /**
     * Sets the value of the itemStatus property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemStatus(String value) {
        this.itemStatus = value;
    }

    /**
     * Gets the value of the fulfillingLocationCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillingLocationCd() {
        return fulfillingLocationCd;
    }

    /**
     * Sets the value of the fulfillingLocationCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillingLocationCd(String value) {
        this.fulfillingLocationCd = value;
    }

    /**
     * Gets the value of the fulfillingSystemCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFulfillingSystemCd() {
        return fulfillingSystemCd;
    }

    /**
     * Sets the value of the fulfillingSystemCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFulfillingSystemCd(String value) {
        this.fulfillingSystemCd = value;
    }

    /**
     * Gets the value of the lineNo property.
     * 
     */
    public int getLineNo() {
        return lineNo;
    }

    /**
     * Sets the value of the lineNo property.
     * 
     */
    public void setLineNo(int value) {
        this.lineNo = value;
    }

    /**
     * Gets the value of the requestingSystemLineNo property.
     * 
     */
    public int getRequestingSystemLineNo() {
        return requestingSystemLineNo;
    }

    /**
     * Sets the value of the requestingSystemLineNo property.
     * 
     */
    public void setRequestingSystemLineNo(int value) {
        this.requestingSystemLineNo = value;
    }

    /**
     * Gets the value of the statusDate property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatusDate() {
        return statusDate;
    }

    /**
     * Sets the value of the statusDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatusDate(String value) {
        this.statusDate = value;
    }

    /**
     * Gets the value of the itemUpcCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemUpcCd() {
        return itemUpcCd;
    }

    /**
     * Sets the value of the itemUpcCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemUpcCd(String value) {
        this.itemUpcCd = value;
    }

    /**
     * Gets the value of the itemEanCd property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getItemEanCd() {
        return itemEanCd;
    }

    /**
     * Sets the value of the itemEanCd property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setItemEanCd(String value) {
        this.itemEanCd = value;
    }

    /**
     * Gets the value of the orderLineExtendedFreight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineExtendedFreight() {
        return orderLineExtendedFreight;
    }

    /**
     * Sets the value of the orderLineExtendedFreight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineExtendedFreight(BigDecimal value) {
        this.orderLineExtendedFreight = value;
    }

    /**
     * Gets the value of the orderLineCustomizationCharge property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineCustomizationCharge() {
        return orderLineCustomizationCharge;
    }

    /**
     * Sets the value of the orderLineCustomizationCharge property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineCustomizationCharge(BigDecimal value) {
        this.orderLineCustomizationCharge = value;
    }

    /**
     * Gets the value of the orderLineGiftWrap property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineGiftWrap() {
        return orderLineGiftWrap;
    }

    /**
     * Sets the value of the orderLineGiftWrap property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineGiftWrap(String value) {
        this.orderLineGiftWrap = value;
    }

    /**
     * Gets the value of the orderLineShipAlone property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineShipAlone() {
        return orderLineShipAlone;
    }

    /**
     * Sets the value of the orderLineShipAlone property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineShipAlone(String value) {
        this.orderLineShipAlone = value;
    }

    /**
     * Gets the value of the orderLineShipWeight property.
     * 
     * @return
     *     possible object is
     *     {@link BigDecimal }
     *     
     */
    public BigDecimal getOrderLineShipWeight() {
        return orderLineShipWeight;
    }

    /**
     * Sets the value of the orderLineShipWeight property.
     * 
     * @param value
     *     allowed object is
     *     {@link BigDecimal }
     *     
     */
    public void setOrderLineShipWeight(BigDecimal value) {
        this.orderLineShipWeight = value;
    }

    /**
     * Gets the value of the orderLineMessage property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getOrderLineMessage() {
        return orderLineMessage;
    }

    /**
     * Sets the value of the orderLineMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setOrderLineMessage(String value) {
        this.orderLineMessage = value;
    }

}
