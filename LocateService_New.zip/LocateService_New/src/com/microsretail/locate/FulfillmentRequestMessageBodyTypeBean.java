
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for FulfillmentRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="FulfillmentRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="store_location" type="{http://microsretail.com/Locate}FulfillmentRequestMessageStoreLocationTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "FulfillmentRequestMessageBodyTypeBean", propOrder = {
    "storeLocation"
})
public class FulfillmentRequestMessageBodyTypeBean {

    @XmlElement(name = "store_location", required = true)
    protected FulfillmentRequestMessageStoreLocationTypeBean storeLocation;

    /**
     * Gets the value of the storeLocation property.
     * 
     * @return
     *     possible object is
     *     {@link FulfillmentRequestMessageStoreLocationTypeBean }
     *     
     */
    public FulfillmentRequestMessageStoreLocationTypeBean getStoreLocation() {
        return storeLocation;
    }

    /**
     * Sets the value of the storeLocation property.
     * 
     * @param value
     *     allowed object is
     *     {@link FulfillmentRequestMessageStoreLocationTypeBean }
     *     
     */
    public void setStoreLocation(FulfillmentRequestMessageStoreLocationTypeBean value) {
        this.storeLocation = value;
    }

}
