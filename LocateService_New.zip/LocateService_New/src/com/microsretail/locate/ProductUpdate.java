
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductUpdate complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductUpdate"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="product_update_request_message" type="{http://microsretail.com/Locate}ProductUpdateRequestMessageTypeBean" minOccurs="0" form="qualified"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductUpdate", propOrder = {
    "productUpdateRequestMessage"
})
public class ProductUpdate {

    @XmlElement(name = "product_update_request_message", namespace = "http://microsretail.com/Locate")
    protected ProductUpdateRequestMessageTypeBean productUpdateRequestMessage;

    /**
     * Gets the value of the productUpdateRequestMessage property.
     * 
     * @return
     *     possible object is
     *     {@link ProductUpdateRequestMessageTypeBean }
     *     
     */
    public ProductUpdateRequestMessageTypeBean getProductUpdateRequestMessage() {
        return productUpdateRequestMessage;
    }

    /**
     * Sets the value of the productUpdateRequestMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductUpdateRequestMessageTypeBean }
     *     
     */
    public void setProductUpdateRequestMessage(ProductUpdateRequestMessageTypeBean value) {
        this.productUpdateRequestMessage = value;
    }

}
