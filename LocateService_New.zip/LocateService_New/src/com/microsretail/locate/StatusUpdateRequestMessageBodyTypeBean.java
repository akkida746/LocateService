
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for StatusUpdateRequestMessageBodyTypeBean complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="StatusUpdateRequestMessageBodyTypeBean"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="order" type="{http://microsretail.com/Locate}StatusUpdateRequestMessageOrderTypeBean"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "StatusUpdateRequestMessageBodyTypeBean", propOrder = {
    "order"
})
public class StatusUpdateRequestMessageBodyTypeBean {

    @XmlElement(required = true)
    protected StatusUpdateRequestMessageOrderTypeBean order;

    /**
     * Gets the value of the order property.
     * 
     * @return
     *     possible object is
     *     {@link StatusUpdateRequestMessageOrderTypeBean }
     *     
     */
    public StatusUpdateRequestMessageOrderTypeBean getOrder() {
        return order;
    }

    /**
     * Sets the value of the order property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusUpdateRequestMessageOrderTypeBean }
     *     
     */
    public void setOrder(StatusUpdateRequestMessageOrderTypeBean value) {
        this.order = value;
    }

}
