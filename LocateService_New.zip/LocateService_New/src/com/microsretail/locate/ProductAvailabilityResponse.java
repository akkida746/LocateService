
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductAvailabilityResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductAvailabilityResponse"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="product_availability_response_message" type="{http://microsretail.com/Locate}ProductAvailabilityResponseMessageTypeBean" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductAvailabilityResponse", propOrder = {
    "productAvailabilityResponseMessage"
})
public class ProductAvailabilityResponse {

    @XmlElement(name = "product_availability_response_message")
    protected ProductAvailabilityResponseMessageTypeBean productAvailabilityResponseMessage;

    /**
     * Gets the value of the productAvailabilityResponseMessage property.
     * 
     * @return
     *     possible object is
     *     {@link ProductAvailabilityResponseMessageTypeBean }
     *     
     */
    public ProductAvailabilityResponseMessageTypeBean getProductAvailabilityResponseMessage() {
        return productAvailabilityResponseMessage;
    }

    /**
     * Sets the value of the productAvailabilityResponseMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link ProductAvailabilityResponseMessageTypeBean }
     *     
     */
    public void setProductAvailabilityResponseMessage(ProductAvailabilityResponseMessageTypeBean value) {
        this.productAvailabilityResponseMessage = value;
    }

}
