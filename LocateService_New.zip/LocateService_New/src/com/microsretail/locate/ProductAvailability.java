
package com.microsretail.locate;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for ProductAvailability complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="ProductAvailability"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="product_availability_request_message" type="{http://microsretail.com/Locate}AvailabilityByOrderTypeRequestMessageTypeBean" minOccurs="0" form="qualified"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ProductAvailability", propOrder = {
    "productAvailabilityRequestMessage"
})
public class ProductAvailability {

    @XmlElement(name = "product_availability_request_message", namespace = "http://microsretail.com/Locate")
    protected AvailabilityByOrderTypeRequestMessageTypeBean productAvailabilityRequestMessage;

    /**
     * Gets the value of the productAvailabilityRequestMessage property.
     * 
     * @return
     *     possible object is
     *     {@link AvailabilityByOrderTypeRequestMessageTypeBean }
     *     
     */
    public AvailabilityByOrderTypeRequestMessageTypeBean getProductAvailabilityRequestMessage() {
        return productAvailabilityRequestMessage;
    }

    /**
     * Sets the value of the productAvailabilityRequestMessage property.
     * 
     * @param value
     *     allowed object is
     *     {@link AvailabilityByOrderTypeRequestMessageTypeBean }
     *     
     */
    public void setProductAvailabilityRequestMessage(AvailabilityByOrderTypeRequestMessageTypeBean value) {
        this.productAvailabilityRequestMessage = value;
    }

}
